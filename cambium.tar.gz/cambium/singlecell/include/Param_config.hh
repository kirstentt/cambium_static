#ifndef ConfigHeader
#define ConfigHeader

using namespace std;

#include "Basic_params.hh"
#include "Plant_layout.hh"
#include <cstring>

//Below the #define XXX statements allow you to switch between
//different types of conditions to be simulated
//To "activate" a define statement uncomment it (no // in front)
//to "inactivate a define statement comment it (// in front)



//only on of the three below should be switched on
#define SINGLECELL1
// #define STRONGANTREPRESSION 
// #define STRONGSEQUESTRATION 

// #define EXPLICITPXYBINDING

#ifdef STRONGSEQUESTRATION
#define EXPLICITPXYBINDING //if this is not defined, we calculate PXY-CLE as a steady
// state of the current PXY and CLE levels, and avoid the sequestering effect.
//This is used under the strong HDZIPIII scenario to model a non-sequester example.
#endif



#ifndef STRONGSEQUESTRATION
#define HDZIPFULLEFF
#else
#define HDZIPAUXINEFFONLY //this is defined under the strong sequestering example to
//restrict the HDZIPIII repression to small faction of ANT induction directly caused by auxin.
#endif


const double auxmax_min =100;/// 100.;
extern double auxmax; // auxmax (the maximum auxin level in the xylem) is set by auxmax_min
const double globalCLEprod_min =0*0.004;//4.33 to compensate for faster C decay
const double extraCLEprod = 0.00;
extern double globalCLEprod;
//#define MULTIRUN //turn this on if you want to do a series of runs instead of a singular one. Will create nested directories for different runs
#ifdef MULTIRUN
const double auxmax_stepsize = 10.;
const double auxmax_maxsize = 100.;
const double globalCLEprod_stepsize= 0.004;
const double globalCLEprod_maxsize = 0.0202;
#endif

#define LOWERAUXUNDIF 	// if this is turned on the cells xylemward of the xylem organiser have less auxin than the auxin maximum.
			// if undefined all these cells will have the maximum auxin level and auxin drops after the xylem organiser.
#define PHLOEMAUXINGRAD // if this is turned on the phloem has explicit auxin levels depending on the exponential gradient. 




//delays changes in the auxin shifts to create a more gradual transition when a new xylem organiser is formed and the gradient is repositioned.
//only has an effect in growing tissues, not so relevant in this code.
const double auxdelay = 0.01;


//Gene expression parameters

const double maxPlts=0.002;
const double decayPlts=0.00002;
const double pltsfac=1.;
const double pltsdiff = 0.00002;
//PLT plasmodesmatal flux rate 
const double pdflux=0.04/(double)xstep;
const double PXYKMPLTS = 40;
const double PXYkmPLTpwr = 2;


//PXY parameters
const double maxPXY=  0.12;// 0.12 is 100% PXY; 0.06 is 50% PXY; 0.04 is 33.33% PXY; 0.03 is 25% PXY.
const double decayPXY=0.0012;
const double auxkmPXY = 25;
const double auxkmPXYpwr= 2;
const double PltsKMPXY = 50;
const double pltskmPXYpwr = 2;
const double PltsfacPXY = 0.3;
const double targetdegraded =  0.0012;//this should be equal to the PXY degradation rate.

#ifndef STRONGSEQUESTRATION
const double maxCLE41=0.03;
#else
const double maxCLE41=0.13;
#endif
#ifdef SINGLECELL1
const double PXYdiss = 0.1;
#endif
#ifdef SINGLECELL2
const double PXYdiss = 0.1;
#endif
#ifdef STRONGSEQUESTRATION
const double PXYdiss =   0.02;
#endif
#ifdef STRONGANTREPRESSION
const double PXYdiss = 0.02;
#endif
const double decayCLE41 = 0.0002;
const double CLE41diff= 0.015; // basic diffusion rate for CLE
const double PXYass = 0.02;



//ANT PARAMETERS
const double maxANT= 0.002;
const double decayANT = 0.00002;
const double ANTPXYfac = 0.8; // ANTPXYfac and ANTAuxfac together may not exceed 1. If they are below 1 the remaining value represents 'always on' induction' 
const double PXYKMANT = 20;
const double PXYkmANTpwr = 2;
const double ANTAuxfac = 0.2; // ANTPXYfac and ANTAuxfac together may not exceed 1. If they are below 1 the remaining value represents 'always on' induction'
const double AuxinKMANT = 20;
const double AuxinkmANTpwr = 2;
#ifndef SINGLECELL1
const double ANTHDZIPfac = 1;
#endif
#ifdef SINGLECELL1
const double ANTHDZIPfac = 0.4;
#endif
const double HDZIPKMANT = 45;//50??
const double HDZIPKMANTpwr = 2;

//HDZIP parameters
const double maxHDZIP3 = 0.02;
const double decayHDZIP3 = 0.0002;
const double facHDZIP3 = 1.0;
const  double AuxKMHDZIP = 55;
const double auxkmhdzippwr = 4;


#endif






