/*

DigitalRoot simulates the regulation of root growth and developmental 
zonation by the phytohormone auxin and the PLETHORA transcription factors  
in a simplified, two dimensional model of the Arabidopsis root.

Copyright 2012-2014, Kirsten ten Tusscher


DigitalRoot is distributed under the terms of the GNU General Public 
License.


DigitalRoot is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

DigitalRoot is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with DigitalRoot.  If not, see <http://www.gnu.org/licenses/>.

*/
#include "Param_config.hh"
#include "Basic_params.hh"
#include "Functions.hh"
#include "Arrays.hh"
#include "Plant_layout.hh"



double  sweepresults[11][6][3];
long sweepcounter;

char dirname[2000];
char maindirname[2000];
int actcells;
//sweeping parameters
double auxmax;
double globalCLEprod;


double PXYKMPLTS;
double auxkmPXY;
double PltsKMPXY;
double PltsfacPXY;
double PXYKMANT;
double AuxinKMANT;
double ANTHDZIPfac;
double HDZIPKMANT;
double AuxKMHDZIP;



//Grid based properties
int Tc[n][m];
int **Tmt;



//Cell based properties
int Cell[n][m];
int CellSizes[totcells];
double InvCellSizes[totcells];
int CellMinI[totcells];
int CellMinJ[totcells];
int CellMaxI[totcells];
int CellMaxJ[totcells];
int CellWidth[totcells];
int CellHeight[totcells];
int CellZonationState[totcells];
double ARF[totcells];
double Plts[totcells];
double HDZIP3[totcells];
double ANT[totcells];
double CLE41[totcells];
double PXY[totcells];
double PXYbound[totcells];



void MakeArrays()
{

  int i,j,k;            	

  for(i=0;i<n;i++)
    for(j=0;j<m;j++)
      Tc[i][j]=0;
  //Tmt
  if (( Tmt = new int*[n]) == NULL )
    { printf("error in allocating Tmt array\n"); exit(1);}
  for ( i = 0; i < n; i++ )
    {
      if (( Tmt[i] = new int[m]) == NULL )
	{ printf("error in allocating Tmt array\n"); exit(1);}
    }
  for(i=0;i<n;i++)
    for(j=0;j<m;j++)
      Tmt[i][j]=0;
}

void FreeArrays()
{
  int i,j;

  for(i = 0; i < n; i++)
    delete[] Tmt[i];
  delete[] Tmt;
}
  

void Start(int argc, char **argv)
{
  if(argc<2)
    {
      printf("usage: exc dirname\n");
      exit(1);
    }
  else
    {
      strcpy(dirname,argv[1]);
      strcpy(maindirname,argv[1]);
    }
}

void MakePNGFileSWEEP(char *dirname, double C[11][6][3])
{
  int i,j;
  int ii,jj;
  
  FILE *PNGFileP;
  png_structp png_ptr;
  png_infop info_ptr;
  png_bytep row_pointer;
  char fname[500];
  const int WW=6;//11;//auxin
  const int LL=11;//6 //TDIF
  unsigned char RGBdata[LL*WW*3];
  int colour;
  int CColour[LL][WW];
  double temp;
  int q;
  
  sprintf(fname,"%s/SWEEPresults.png",dirname);   
  
  for(i=0;i<11;i++)
    for(j=0;j<6;j++)
      {
	ii=i ;
	jj=j ;
	
	RGBdata[jj*LL*3+ii*3+0]=254*C[i][j][0];             
	RGBdata[jj*LL*3+ii*3+1]=254*C[i][j][1];             
	RGBdata[jj*LL*3+ii*3+2]=254*C[i][j][2]; 
      }
	   
  PNGFileP = fopen(fname, "wb");
  png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING,(png_voidp) NULL,
                    (png_error_ptr) NULL,
                    (png_error_ptr) NULL );
  if(!png_ptr){
    printf("out of memory\n");
    exit(1);
  }
  info_ptr = png_create_info_struct ( png_ptr );
  if(!info_ptr){
    png_destroy_write_struct(&png_ptr, NULL);
    printf("out of memory\n");
    exit(1);
  }
  png_init_io ( png_ptr, PNGFileP );
  png_set_IHDR(png_ptr, info_ptr,LL,WW,
           8, PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE,
           PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
  png_write_info ( png_ptr, info_ptr );
  /*write out image, one row at a time*/
  int row;
  for(row = WW-1; row >= 0; row--){
    row_pointer = ( RGBdata + LL * row * 3 );
    png_write_rows ( png_ptr, &row_pointer, 1 );
  }
  png_write_end ( png_ptr, info_ptr );
  fflush ( PNGFileP );
  png_destroy_write_struct ( &png_ptr,&info_ptr);
  fclose(PNGFileP);
}  




int single_run(int argc)
{
  double dummypict[n][m];
  int time;
  int i,j,q,k;
  int starttime;

  SetUpMembraneTypes();
#ifndef RESTART
  starttime=0;
  InitPlant();
#else
  starttime=givenstart;
  InitPlantFromFile(starttime);
  starttime=(int)(starttime/tstep);
#endif

    
  for(time=starttime;time<=maxnrsteps;time++)
    {
	  

      if(time%speedup2==0)
	{
	  UpdateGeneExpression((int)(time*tstep));
	}
      

#ifndef SIMPLEPLOT
      if((int)(time*tstep)>0 && (int)(time*tstep)%50000==0)
	WritePlantToFile((int)(time*tstep));
      
      if(time%tsave==0)
	{
	  
	  for(q=0;q<actcells;q++)
	    {
	      SaveTemp((int)(time*tstep),(int)(0.5*(CellMinI[q]+CellMaxI[q])),(int)(0.5*(CellMinJ[q]+CellMaxJ[q])));
	    }
	  
	  //for png pictures we need double values
	  //dummyarray is uded tp go from int to double
	  for(i=0;i<n;i++)
	    for(j=0;j<m;j++)
	      dummypict[i][j]=Tc[i][j];
	  MakePNGFile(dirname,dummypict,(int)(time*tstep),0);

	  
	  //for png we also need values at grid level instead of cell level
	  //here we use a function to project cell level to grid level values
	  //before calling the MakePNGFile function within this function
	  prepare_Int_PNG(CellZonationState,9,(int)(time*tstep),dirname);
	  prepare_PNG(PXY,10,(int)(time*tstep),dirname);
	  prepare_PNG(PXYbound,15,(int)(time*tstep),dirname);
	  prepare_PNG(CLE41,11,(int)(time*tstep),dirname);
	  prepare_PNG(ANT,12,(int)(time*tstep),dirname);
	  prepare_PNG(HDZIP3,13,(int)(time*tstep),dirname);
	  prepare_PNG(ARF,3,(int)(time*tstep),dirname);
	  prepare_PNG(Plts,4,(int)(time*tstep),dirname);
	  prepare_Int_PNG(CellZonationState,14,(int)(time*tstep),dirname);


	  //to make a picture combining the above separate pictures
	  make_combined_figure(dirname,(int)(time*tstep));


	  Trackcontentfirst(time*tstep);
	  Trackcontentsecond(time*tstep);
	 
	}
#else
      if(time%tsave==0 && time>1000)
	{ 
	  // Trackcontentfirstsweep(time*tstep);
	  //Trackcontentsecondsweep(time*tstep); //simplified output for sweep //WHERE IS THIS FUNCTION?
	}
#endif
    }  

  return 0;
}


//vary auxin and TDIF values
int multimain(int argc, char **argv)
{

 char s[9000];

 cout << "auxmaxes min" <<auxmax_min << " max "<< auxmax_maxsize << " step " <<auxmax_stepsize<<std::endl;

 std::string basedirname = dirname;
 for(auxmax = auxmax_min;auxmax<auxmax_maxsize;auxmax+=auxmax_stepsize)
   {
     for(globalCLEprod = globalCLEprod_min;globalCLEprod < globalCLEprod_maxsize; globalCLEprod+=globalCLEprod_stepsize)
       {
	 char s[3000];
	 char auxname[3000];
	 sprintf(auxname,"%.1f",auxmax);
	 char CLEname[3000];
	 sprintf(CLEname,"%.4f",globalCLEprod);
	 std::string newdirname = std::string(basedirname) +std::string("//auxinmax_")+ std::string(auxname)+ std::string("CLEprod_")+std::string(CLEname);
	 cout << "newdirname " << newdirname <<std::endl;
	 strcpy(dirname,newdirname.c_str());
	 sprintf(s,"mkdir %s",dirname);
	 system(s);
	 cout << "params " << PXYKMPLTS << " " <<auxkmPXY << " " <<  PltsKMPXY << " "<< PltsfacPXY << " "<< PXYKMANT << " " << AuxinKMANT  << " "<< ANTHDZIPfac << " " << AuxKMHDZIP<< std::endl;
	 
	 single_run(argc);                              
       }
   }
 //store overall sweep results

 return 0;
}


//single run so no intricate directory structure.
 int singlemain(int argc, char **argv)
{
 auxmax = auxmax_min;
 globalCLEprod = globalCLEprod_min;
 single_run(argc);
 return 0;
}

int sweepmain(int argc, char **argv)
{
	
  char s[9000];
  sweepcounter=0;
  int i,j;

  std::string baseDirname= std::string(dirname)+"/";
  for(PXYKMPLTS = PXYKMPLTSmin;PXYKMPLTS<=PXYKMPLTSmax;PXYKMPLTS+=PXYKMPLTSstep)//1
    {
      char PXKPL[20];
      sprintf(PXKPL,"%.1f",PXYKMPLTS);
      std::string PXYKMPLTSname = std::string(baseDirname)+std::string("PXKPL")+ std::string(PXKPL)+std::string("/");
      strcpy(dirname,PXYKMPLTSname.c_str());
      sprintf(s,"mkdir %s",dirname);
      system(s);
      std::string base1Dirname = dirname;
    
      for(auxkmPXY = auxkmPXYmin;auxkmPXY<=auxkmPXYmax;auxkmPXY+=auxkmPXYstep)//2
	{
	  char AUKPX[20];
	  sprintf(AUKPX,"%.1f",auxkmPXY);
	  std::string PXYKMPLTSname =  std::string(base1Dirname)+std::string("AUKPX")+ std::string(AUKPX)+std::string("/");
	  strcpy(dirname,PXYKMPLTSname.c_str());
	  sprintf(s,"mkdir %s",dirname);
	  system(s);
	  std::string base2Dirname = dirname;
	  
	  for(PltsKMPXY = PltsKMPXYmin;PltsKMPXY<=PltsKMPXYmax;PltsKMPXY+= PltsKMPXYstep)//3
	    {
	      char PLKPX[20];
	      sprintf(PLKPX,"%.1f",PltsKMPXY);
	      std::string PltsKMPXYname = std::string(base2Dirname)+std::string("PLKPX")+ std::string(PLKPX)+std::string("/");
	      strcpy(dirname,PltsKMPXYname.c_str());
	      sprintf(s,"mkdir %s",dirname);
	      system(s);
	      std::string base3Dirname = dirname;

	      for(PltsfacPXY = PltsfacPXYmin;PltsfacPXY<=PltsfacPXYmax;PltsfacPXY+=PltsfacPXYstep)//4
		{
		  char PLFPX[20];
		  sprintf(PLFPX,"%.2f",PltsfacPXY);
		  std::string PltsfacPXYname = std::string(base3Dirname)+std::string("PLFPX")+ std::string(PLFPX)+std::string("/");
		  strcpy(dirname,PltsfacPXYname.c_str());
		  sprintf(s,"mkdir %s",dirname);
		  system(s);
		  std::string base4Dirname = dirname;
          
		  for(PXYKMANT = PXYKMANTmin;PXYKMANT<=PXYKMANTmax+1;PXYKMANT+=PXYKMANTstep)//5
		    {
		      char PXKAN[20];
		      sprintf(PXKAN,"%.f",PXYKMANT);
		      std::string PXYKMANTname = std::string(base4Dirname)+std::string("PXKAN")+ std::string(PXKAN)+std::string("/");
		      strcpy(dirname,PXYKMANTname.c_str());
		      sprintf(s,"mkdir %s",dirname);
		      system(s);
		      std::string base5Dirname = dirname;
	        
		      for(AuxinKMANT = AuxinKMANTmin;AuxinKMANT<=AuxinKMANTmax+1;AuxinKMANT+=AuxinKMANTstep)//6
			{
			  char AuKAN[20];
			  sprintf(AuKAN,"%.1f",AuxinKMANT);
			  std::string AuxinKMANTname = std::string(base5Dirname)+std::string("AuKAN")+ std::string(AuKAN)+std::string("/");
			  strcpy(dirname,AuxinKMANTname.c_str());
			  sprintf(s,"mkdir %s",dirname);
			  system(s);
			  std::string base6Dirname = dirname;
              
			  for(ANTHDZIPfac = ANTHDZIPfacmin;ANTHDZIPfac<=ANTHDZIPfacmax+0.01;ANTHDZIPfac+=ANTHDZIPfacstep)//7
			    {
			      char ANFHD[20];
			      sprintf(ANFHD,"%.2f",ANTHDZIPfac);
			      std::string ANTHDZIPfacname = std::string(base6Dirname)+std::string("ANFHD")+ std::string(ANFHD)+std::string("/");
			      strcpy(dirname,ANTHDZIPfacname.c_str());
			      sprintf(s,"mkdir %s",dirname);
			      system(s);
			      std::string base7Dirname = dirname;

			      for(HDZIPKMANT = HDZIPKMANTmin;HDZIPKMANT<=HDZIPKMANTmax+1;HDZIPKMANT+=HDZIPKMANTstep)//8
				{
				  char HDKAN[20];
				  sprintf(HDKAN,"%.1f",HDZIPKMANT);
				  std::string HDZIPKMANTame = std::string(base7Dirname)+std::string("HDKAN")+ std::string(HDKAN)+std::string("/");
				  strcpy(dirname,HDZIPKMANTame.c_str());
				  sprintf(s,"mkdir %s",dirname);
				  system(s);
				  std::string base8Dirname = dirname;             
                
				  for(AuxKMHDZIP = AuxKMHDZIPmin;AuxKMHDZIP<=AuxKMHDZIPmax+1;AuxKMHDZIP+=AuxKMHDZIPstep)//9
				    {
				      char AuKHD[20];
				      sprintf(AuKHD,"%.1f",AuxKMHDZIP);
				      std::string AuxKMHDZIPcname = std::string(base8Dirname)+std::string("AuKHD")+ std::string(AuKHD);
				      strcpy(dirname,AuxKMHDZIPcname.c_str());
				      sprintf(s,"mkdir %s",dirname);
				      system(s);
				      std::string base9Dirname = dirname;
				      // multimain(argc, argv);
				      cout << base9Dirname << std::endl;
				      for(auxmax = auxmax_min;auxmax<auxmax_maxsize;auxmax+=auxmax_stepsize){
					for(globalCLEprod = globalCLEprod_min;globalCLEprod < globalCLEprod_maxsize; globalCLEprod+=globalCLEprod_stepsize)
					  {

					    single_run(argc);
					    
					    
					    //we need to store the outcome (cell type) in a auxin X TDIF matrix
					    //dimension 1: auxin value (0-100, stepsize 10  so 11 entries)
					    //dimension 2: TDIF value (0-100, stepsize 20 so 6 entries)
					    //dimension 3: 3 entries 0: xylem, 1: cambium 3: phloem
					    //first compute dimension 1
					    i=(int) (auxmax-auxmax_min)/auxmax_stepsize;
					    //second compute dimension 2
					    j=(int)((globalCLEprod-globalCLEprod_min)/globalCLEprod_stepsize);
					    
					    
					    //thirdly determine celltype
					    int xylem= 0;
					    int cambium= 0;
					    int phloem= 0;
					    
					    if((Plts[0]+ANT[0])>75)
					      cambium=1;
					    else if(HDZIP3[0]>30)
					      xylem=1;
					    else
					      phloem=1;
					    
					    //need to create this table and initialize all at 0
					    //make it of type double so we can convert counters 
					    //afterwards to fraction/percentage?
					    //need to make counter for total number of parameter sets
					    //needs to be long int
					    
					    sweepcounter++;
					    sweepresults[i][j][0]+=cambium;
					    sweepresults[i][j][1]+=phloem; 
					    sweepresults[i][j][2]+=xylem; 
					    
					  }
				      }
				    }
				}
			    }
			}
		    }
		}
	    }
	}
    }
  printf("finished sweep, going to compute results\n"); 
  
  printf("sweepcounter is %i\n",sweepcounter);
  sweepcounter/=66;//computing parameter sweeps, not auxin*TDIF matrix
  printf("sweepcounter is %i\n",sweepcounter);
  //computing fraction of parameter sweeps giving certain outcome
  for(i=0;i<11;i++)
    for(j=0;j<6;j++)
      {
	sweepresults[i][j][0]/=sweepcounter;//cambium// R
	sweepresults[i][j][1]/=sweepcounter;//phloem // G
	sweepresults[i][j][2]/=sweepcounter;//xylem  // B

	//	printf("auxin step %i TDIF step %i results %f %f %f\n",i,j,sweepresults[i][j][0],sweepresults[i][j][1],sweepresults[i][j][2]);
      }
  printf("computed results, going to write them to figure\n");

  MakePNGFileSWEEP(maindirname,sweepresults);    
   
 cout << "Finished full set " << std::endl;
 return 0;
}




int main(int argc, char **argv)
{

  Start(argc,argv);
  MakeArrays();

#ifdef PARAMSWEEP
  sweepmain(argc,argv);//vary 9 parameters AND auxin and TDIF
#else
#ifdef MULTIRUN
  multimain(argc,argv);//vary auxin and TDIF
#else
  singlemain(argc,argv);//single value auxin and TDIF
#endif
#endif
 FreeArrays();
 return 0;
}
