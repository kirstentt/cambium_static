
#ifndef PlantHeader
#define PlantHeader

using namespace std;
#include <iostream>

/*************************************************************************************************/

//The next series of define statements below are used to set up the size of the
//digital root tissue and its consitutent cells

#define N 50                   //width of cells

#define M1 64                 //initial height of Xylem cells
#define M2 16                  //initial height of Cambium cells
#define M3 32                 //initial height of fully developped Phloem cells
#define M4 24                 //initial height of Xylem organizer cells
#define M5 16                 //initial height of developping Phloem cells

#define z1 1                  //width of cell walls
#define X 1                   //nr of cells in x-direction
#define Y1 0                 //initial nr of XYLEM cells
#define Y2 2                  //initial nr of Cambium cells
#define Y3 1             //initial nr of PHLOEM cells
#define Y4 1             //initial nr of Xylem organizer cells
#define Y5 0                 //initial nr of developing phloem cells
#define Y 20
#define zoom 1                //zoom factor used for display
#define n (X*(N+2*z1))        //size of field in x-dir 
#define bufsize 30            //buffer around simulation domain
#define m (Y*(M1+1))+2*bufsize //size of field in y-dir, lot of excess as we only need M1*Y1+M2*Y2+M3*Y3+M4*Y4+M5*Y5+2*z1+2*bufsize+walls in between
#define totcells  200        //maximum totalnr of cells possible in simulation
#define xm n/2 //half of simulation grid width
extern int actcells;          //actual current nr of cells in simulation



#endif
