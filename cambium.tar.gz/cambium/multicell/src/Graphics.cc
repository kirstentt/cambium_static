/*

DigitalRoot simulates the regulation of root growth and developmental 
zonation by the phytohormone auxin and the PLETHORA transcription factors  
in a simplified, two dimensional model of the Arabidopsis root.

Copyright 2012-2014, Kirsten ten Tusscher


DigitalRoot is distributed under the terms of the GNU General Public 
License.


DigitalRoot is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

DigitalRoot is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with DigitalRoot.  If not, see <http://www.gnu.org/licenses/>.

*/
#include "Param_config.hh"
#include "Basic_params.hh"
#include "Functions.hh"
#include "Arrays.hh"
#include "Plant_layout.hh"


static int colourmap[255][3]=
{{0, 0, 0},
{0, 0, 7},
{0, 0, 9},
{0, 0, 12},
{0, 0, 14},
{0, 0, 17},
{0, 0, 19},
{0, 0, 22},
{0, 0, 24},
{0, 0, 27},
{0, 0, 29},
{0, 0, 32},
{0, 0, 34},
{0, 0, 37},
{0, 0, 39},
{0, 0, 42},
{0, 0, 44},
{0, 0, 47},
{0, 0, 49},
{0, 0, 52},
{0, 0, 54},
{0, 0, 57},
{0, 0, 59},
{0, 0, 62},
{0, 0, 64},
{0, 0, 67},
{0, 0, 69},
{0, 0, 72},
{0, 0, 74},
{0, 0, 77},
{0, 0, 79},
{0, 0, 82},
{0, 0, 84},
{0, 0, 87},
{0, 0, 89},
{0, 0, 92},
{0, 0, 94},
{0, 0, 97},
{0, 0, 99},
{0, 0, 102},
{0, 0, 104},
{0, 0, 107},
{0, 0, 109},
{0, 0, 112},
{0, 0, 114},
{0, 0, 117},
{0, 0, 119},
{0, 0, 122},
{0, 0, 124},
{0, 0, 127},
{0, 0, 129},
{3, 0, 127},
{7, 0, 126},
{10, 0, 124},
{13, 0, 122},
{16, 0, 121},
{19, 0, 119},
{22, 0, 117},
{26, 0, 116},
{29, 0, 114},
{32, 0, 112},
{35, 0, 111},
{38, 0, 109},
{41, 0, 107},
{44, 0, 106},
{48, 0, 104},
{51, 0, 102},
{54, 0, 101},
{57, 0, 99},
{60, 0, 97},
{63, 0, 96},
{66, 0, 94},
{69, 0, 93},
{72, 0, 92},
{75, 0, 90},
{77, 0, 89},
{80, 0, 88},
{83, 0, 86},
{87, 0, 85},
{90, 0, 84},
{93, 0, 82},
{96, 0, 81},
{98, 0, 80},
{101, 0, 78},
{104, 0, 77},
{107, 0, 76},
{110, 0, 74},
{113, 0, 73},
{116, 0, 72},
{119, 0, 70},
{120, 0, 69},
{123, 0, 68},
{126, 0, 66},
{127, 0, 64},
{129, 0, 63},
{132, 0, 62},
{135, 0, 60},
{137, 0, 58},
{140, 0, 56},
{143, 0, 54},
{146, 0, 52},
{149, 0, 51},
{151, 0, 50},
{154, 0, 48},
{157, 0, 47},
{160, 0, 46},
{163, 0, 44},
{165, 0, 43},
{168, 0, 42},
{171, 0, 40},
{174, 0, 39},
{176, 0, 38},
{179, 0, 36},
{182, 0, 35},
{185, 0, 34},
{188, 0, 32},
{190, 0, 31},
{193, 0, 30},
{196, 0, 28},
{199, 0, 27},
{202, 0, 26},
{204, 0, 24},
{207, 0, 23},
{210, 0, 22},
{213, 0, 20},
{215, 0, 19},
{218, 0, 18},
{221, 0, 16},
{224, 0, 15},
{227, 0, 14},
{229, 0, 12},
{232, 0, 11},
{235, 0, 10},
{238, 0, 8},
{241, 0, 7},
{243, 0, 6},
{246, 0, 4},
{249, 0, 3},
{252, 0, 2},
{255, 0, 0},
{255, 0, 0},
{255, 3, 0},
{255, 6, 0},
{255, 8, 0},
{255, 11, 0},
{255, 13, 0},
{255, 16, 0},
{255, 18, 0},
{255, 21, 0},
{255, 24, 0},
{255, 26, 0},
{255, 29, 0},
{255, 31, 0},
{255, 34, 0},
{255, 36, 0},
{255, 39, 0},
{255, 41, 0},
{255, 43, 0},
{255, 47, 0},
{255, 49, 0},
{255, 52, 0},
{255, 55, 0},
{255, 58, 0},
{255, 61, 0},
{255, 64, 0},
{255, 67, 0},
{255, 70, 0},
{255, 72, 0},
{255, 75, 0},
{255, 77, 0},
{255, 80, 0},
{255, 83, 0},
{255, 85, 0},
{255, 88, 0},
{255, 90, 0},
{255, 93, 0},
{255, 96, 0},
{255, 98, 0},
{255, 101, 0},
{255, 104, 0},
{255, 106, 0},
{255, 109, 0},
{255, 111, 0},
{255, 114, 0},
{255, 117, 0},
{255, 119, 0},
{255, 122, 0},
{255, 124, 0},
{255, 127, 0},
{255, 130, 0},
{255, 132, 0},
{255, 135, 0},
{255, 137, 0},
{255, 140, 0},
{255, 142, 0},
{255, 145, 0},
{255, 148, 0},
{255, 150, 0},
{255, 153, 0},
{255, 155, 0},
{255, 158, 0},
{255, 160, 0},
{255, 163, 0},
{255, 166, 0},
{255, 168, 0},
{255, 171, 0},
{255, 173, 0},
{255, 176, 0},
{255, 178, 0},
{255, 180, 0},
{255, 183, 0},
{255, 186, 0},
{255, 188, 0},
{255, 191, 0},
{255, 193, 0},
{255, 196, 0},
{255, 198, 0},
{255, 201, 0},
{255, 204, 0},
{255, 207, 0},
{255, 209, 0},
{255, 212, 0},
{255, 215, 0},
{255, 218, 0},
{255, 221, 0},
{255, 223, 0},
{255, 226, 0},
{255, 229, 0},
{255, 231, 0},
{255, 234, 0},
{255, 236, 0},
{255, 239, 0},
{255, 242, 0},
{255, 245, 0},
{255, 248, 0},
{255, 251, 0},
{255, 255, 0},
{255, 255, 14},
{255, 255, 28},
{255, 255, 43},
{255, 255, 57},
{255, 255, 71},
{255, 255, 85},
{255, 255, 99},
{255, 255, 113},
{255, 255, 128},
{255, 255, 142},
{255, 255, 156},
{255, 255, 170},
{255, 255, 184},
{255, 255, 199},
{255, 255, 213},
{255, 255, 227},
{255, 255, 241},
{255, 255, 255}
};


double min(double a, double b)
{
  if(a<b)
    return a;
  else
    return b;
}

double max(double a, double b)
{
  if(a>b)
    return a;
  else
    return b;
}

void prepare_PNG(double content[],int flag,int timestep, char *dirname)

{
  int i,j,q;
  double dummypict[n][m];
  for(i=0;i<n;i++){
    for(j=0;j<m;j++){
      if(Cell[i][j]!=-1){
	q=Cell[i][j];
	dummypict[i][j]=(double)content[q];
      }
      else
	dummypict[i][j]=0; 
    }
  }
  MakePNGFile(dirname, dummypict,timestep,flag);
}

void prepare_Int_PNG(int content[],int flag,int timestep, char *dirname)
{
  int i,j,q;
  double dummypict[n][m];
  for(i=0;i<n;i++){
    for(j=0;j<m;j++){
      if(Cell[i][j]!=-1){
	q=Cell[i][j];
	dummypict[i][j]=(double)content[q];
      }
      else
	dummypict[i][j]=0; 
    }
  }
  MakePNGFile(dirname, dummypict,timestep,flag);
}

void make_combined_figure(char *dirname, int t)
{
  char s[3000];
  
  //make zonelines file be named 
  
  int Ycounter = 0;
  int xylemmin=CellMinJ[0];
  int xylemmax=0;
  int cambiummax = 0;
  int phloemmax = CellMaxJ[actcells-1];
  for (int q = 0;q<actcells;q++){
    if (CellZonationState[q] <-1 &&(q==actcells-1|| CellZonationState[q+1])>=-1){
      xylemmax= CellMaxJ[q];
    }
    else if (CellZonationState[q] <60 &&(q==actcells-1|| CellZonationState[q+1]>=60)){
      cambiummax = CellMaxJ[q];
    }
  }
  
  // makes combined picture with names below the zones.
  if (xylemmax>0)
    {    
      sprintf(s,"convert %s/Zonelines_%.8d.png -gravity center -pointsize 20 -annotate 270x270+%i+%i Xyl %s/Zonelines_%.8d.png ",dirname,t,10,(int(m)/2)-((xylemmin+xylemmax)/2),dirname,t);
      system(s);
    }

  if (cambiummax > 0)
    {
      if (phloemmax!=cambiummax)
	{
	  sprintf(s,"convert %s/Zonelines_%.8d.png -gravity center -pointsize 20 -annotate 270x270+%i+%i Cam %s/Zonelines_%.8d.png ",dirname,t,10,(int(m)/2)-((xylemmax+cambiummax)/2),dirname,t);
	  system(s);  
	  sprintf(s,"convert %s/Zonelines_%.8d.png -gravity center -pointsize 20 -annotate 270x270+%i+%i Phlo %s/Zonelines_%.8d.png ",dirname,t,10,(int(m)/2)-((cambiummax+phloemmax)/2),dirname,t);
	  system(s);     
	}
      else
	{
	  sprintf(s,"convert %s/Zonelines_%.8d.png -gravity center -pointsize 20 -annotate 270x270+%i+%i Cam %s/Zonelines_%.8d.png ",dirname,t,10,(int(m)/2)-((cambiummax+phloemmax)/2),dirname,t);
	  system(s);    
	}
    }
  else
    { //no cambium present
      sprintf(s,"convert %s/Zonelines_%.8d.png -gravity center -pointsize 20 -annotate 270x270+%i+%i Phlo %s/Zonelines_%.8d.png ",dirname,t,10,(int(m)/2)-((xylemmax+phloemmax)/2),dirname,t);
      system(s);   
    }
  
  //regular figure production
  sprintf(s,"convert -gravity west label:zone %s/Zonation_%.8d.png  -rotate 90 +append %s/Zonation_%.8d.png",dirname,t,dirname,t);
  system(s);
  sprintf(s,"convert -gravity west label:Aux %s/Localaux_%.8d.png  -rotate 90 +append %s/Localaux_%.8d.png",dirname,t,dirname,t);
  system(s);
  sprintf(s,"convert -gravity west label:HDZIP3 %s/HDZIP3_%.8d.png  -rotate 90 +append %s/HDZIP3_%.8d.png",dirname,t,dirname,t);
  system(s); 
  sprintf(s,"convert -gravity west label:PXY %s/PXY_%.8d.png  -rotate 90 +append %s/PXY_%.8d.png",dirname,t,dirname,t);
  system(s); 
  sprintf(s,"convert -gravity west label:CLE41 %s/CLE41_%.8d.png  -rotate 90 +append %s/CLE41_%.8d.png",dirname,t,dirname,t);
  system(s);  
  sprintf(s,"convert -gravity west label:PLT %s/Plts_%.8d.png  -rotate 90 +append %s/Plts_%.8d.png",dirname,t,dirname,t);
  system(s);    
  sprintf(s,"convert -gravity west label:ANT %s/ANT_%.8d.png  -rotate 90 +append %s/ANT_%.8d.png",dirname,t,dirname,t);
  system(s);    
  sprintf(s,"convert -gravity west label:PXYCLE %s/PXYbound_%.8d.png  -rotate 90 +append %s/PXYbound_%.8d.png",dirname,t,dirname,t);
  system(s);    

  sprintf(s,"convert -gravity west label:Name %s/Zonelines_%.8d.png -rotate 90 +append %s/Zonelines_%.8d.png",dirname,t,dirname,t);
  system(s);        

  

  sprintf(s,"convert  %s/Zonation_%.8d.png %s/Localaux_%.8d.png %s/HDZIP3_%.8d.png %s/PXY_%.8d.png %s/CLE41_%.8d.png %s/PXYbound_%.8d.png %s/Plts_%.8d.png %s/ANT_%.8d.png %s/Zonelines_%.8d.png  -append %s/Combofigure_%.8d.png",dirname,t,dirname,t,dirname,t,dirname,t,dirname,t,dirname,t,dirname,t,dirname,t,dirname,t,dirname,t);
  system(s);
  sprintf(s,"convert  %s/Zonation_%.8d.png %s/Zonelines_%.8d.png  -append %s/Zonewithlines_%.8d.png",dirname,t,dirname,t,dirname,t);
  system(s);

}

void MakePNGFile(char *dirname, double C[n][m],int t,int flag)
{
  int i,j;
  int ii,jj;
  
  FILE *PNGFileP;
  png_structp png_ptr;
  png_infop info_ptr;
  png_bytep row_pointer;
  char fname[500];
  const int WW=zoom*m;
  const int LL=zoom*n;
  unsigned char RGBdata[LL*WW*3];
  int colour;
  int CColour[LL][WW];
  double temp;
  int q;

  
  for(i=0;i<n;i++)
    for(j=0;j<m;j++)
      {
	 temp=C[i][j];
	 	 
	 if(flag==0)
	   colour=temp*80;
	 else if(flag==3)
	   {
	     if(Tc[i][j]!=0 && Tc[i][j]!=3)
	       if (temp > 150)
		 colour = 254;
	       else
		 colour=(int)(35+(254-35)*(temp/100.)); //auxin color
	     else
	       colour=0;

	     if(colour>254)
	       colour=254;
	   }
	 else if(flag==4)
	   {
	     if(Tc[i][j]!=0 && Tc[i][j]!=3)
	       colour=(int)(35+(254-35)*(temp/100.));
	     else
	       colour=0;

	     if(colour>254)
	       colour=254;
	   }
	 else if(flag==9)
	   {
	     if(Tc[i][j]!=0 && Tc[i][j]!=3)
	       {
		 if((int)temp==-1)
		   colour=1;
		 else if((int)temp==-30)
		   colour=2;
		 else if((int)temp==-40)
		   colour=3;
		 else if((int)temp==-50)
		   colour=3;
		 else if((int)temp==-60)
		   colour=4;
		 else if((int)temp==-80)
		   colour=5;
		 else if((int)temp==-100)
		   colour=6;
		 else if((int)temp==30)
		   colour=7;
		 else if((int)temp==50)
		   colour=8;
		 else if((int)temp==60)
		   colour=9;
		 else if((int)temp==100)
		   colour=10;	
	     }       
	     else
	       colour=0;
	   }
	  else if(flag==10)
	    {
	      q= Cell[i][j];
	      if(Tc[i][j]!=0 && Tc[i][j]!=3)
		{
		  q= Cell[i][j];
		  
#ifdef EXPLICITPXYBINDING   //if we do explicit PXY-CLE binding we need to count both unbound and bound CLE to get the total CLE level  
		  if ((temp+PXYbound[q])>100)
		    colour = 254;
		  else 
		    colour=(int)(35+(254-35)*((temp+PXYbound[q])/100));
#else //if we calculate bound TDIF through steady state equation we can simply take the CLE level as the total CLE level.
	        if (temp>100)
		  colour = 254;
	        else 
	          colour=(int)(35+(254-35)*((temp)/100));
#endif  
		}
	     else
	       colour=0;
	   }		   
	  else if(flag==11)
	    {
	      if(Tc[i][j]!=0 && Tc[i][j]!=3)
		{
		  q= Cell[i][j];
#ifdef EXPLICITPXYBINDING   //if we do explicit PXY-CLE binding we need to count both unbound and bound PXY to get the total PXY level 
		  if ((temp+PXYbound[q])>100)
		    colour = 254;
		  else    
		    colour=(int)(35+(254-35)*((temp+PXYbound[q])/100));
#else//if we calculate bound TDIF through steady state equation we can simply take the PXY level as the total PXY level.
		  if ((temp)>100)
		    colour = 254;
		  else
		    colour=(int)(35+(254-35)*((temp)/100));
#endif                                   
		}
	     else
	       colour=0;
	   }	
	  else if(flag==14)
	   {
		
	     if (i >= n/5  && i <= (n*5)/12 && j >= CellMinJ[0] && j< CellMaxJ[actcells-1]){
	       if(Tc[i][j]!=3)
		 {
		   if (Tc[i][j]==0) temp = CellZonationState[Cell[i][j-2]];
		   if((int)temp<-30)
		     colour=4;
		   else if((int)temp<60)
		     colour=1;
		   else
		     colour=9;
		 }
	     }       
	     else
	       colour=254;
	   }   
	  else if(flag==16)
	    { // TDIF colour with higher maximum for color scale. Allows better insight in the CLE gradient//
	      // but no longer allows for direct comparison with PXY.
	      if(Tc[i][j]!=0 && Tc[i][j]!=3)
		{
		  q= Cell[i][j];
		  if ((temp+PXYbound[q])>400)
		    colour = 254;
		  else 
		    {             
#ifdef EXPLICITPXYBINDING         
		      colour=(int)(35+(254-35)*((temp+PXYbound[q])/400));
#else
		      colour=(int)(35+(254-35)*((temp)/400));
#endif   
		    }
		}
	      else
		{
		  colour=0;
		}
	    }
	  else if(flag>2)
	   {
	     if(Tc[i][j]!=0 && Tc[i][j]!=3)
	       colour=(int)(35+(254-35)*(temp/100));
	     else
	       colour=0;
	   }
	 for(ii=0;ii<zoom;ii++)
	   for(jj=0;jj<zoom;jj++)
	     CColour[zoom*i+ii][zoom*j+jj]=colour;                  
       }

   if(flag==0)
     sprintf(fname,"%s/Tissue_%.8d.png",dirname,t);
   else if(flag==3)
     sprintf(fname,"%s/Localaux_%.8d.png",dirname,t); 
   else if(flag==4)
     sprintf(fname,"%s/Plts_%.8d.png",dirname,t);
   else if(flag==9)
     sprintf(fname,"%s/Zonation_%.8d.png",dirname,t);
   else if(flag==10)
     sprintf(fname,"%s/PXY_%.8d.png",dirname,t);
   else if(flag==11)
     sprintf(fname,"%s/CLE41_%.8d.png",dirname,t);
   else if(flag==12)
     sprintf(fname,"%s/ANT_%.8d.png",dirname,t);
   else if(flag==13)
     sprintf(fname,"%s/HDZIP3_%.8d.png",dirname,t);
   else if (flag == 14) 
     sprintf(fname,"%s/Zonelines_%.8d.png",dirname,t);
   else if (flag == 15) 
     sprintf(fname,"%s/PXYbound_%.8d.png",dirname,t);
   else if (flag == 16) 
     sprintf(fname,"%s/CLE41high_%.8d.png",dirname,t);
   
 
   if(flag!=9&& flag !=14)
     {
       for(i=0;i<LL;i++)
	 for(j=0;j<WW;j++)
	   {
	     RGBdata[j*LL*3+i*3+0]=colourmap[CColour[i][j]][0];
	     RGBdata[j*LL*3+i*3+1]=colourmap[CColour[i][j]][1];
	     RGBdata[j*LL*3+i*3+2]=colourmap[CColour[i][j]][2];
	   }
     }
   else
     {
        for(i=0;i<LL;i++)
	 for(j=0;j<WW;j++)
	   {
	     if(CColour[i][j]==0)//walls, non-tissue: black
	       {
		 RGBdata[j*LL*3+i*3+0]=0;
		 RGBdata[j*LL*3+i*3+1]=0;
		 RGBdata[j*LL*3+i*3+2]=0;
	       }
	     else if(CColour[i][j]==1)//SCN: grey
	       {
		 RGBdata[j*LL*3+i*3+0]=101;
		 RGBdata[j*LL*3+i*3+1]=100;
		 RGBdata[j*LL*3+i*3+2]=100;
	       }
	     else if(CColour[i][j]==2)//xylem dividing
	       {
		 RGBdata[j*LL*3+i*3+0]=140;
		 RGBdata[j*LL*3+i*3+1]=140;
		 RGBdata[j*LL*3+i*3+2]=254;
	       }
	     else if(CColour[i][j]==3)//xylem uncomitted but not dividing
	       {
		 RGBdata[j*LL*3+i*3+0]=115;
		 RGBdata[j*LL*3+i*3+1]=115;
		 RGBdata[j*LL*3+i*3+2]=240;
	       }
	       
	     else if(CColour[i][j]==4)//xylem organizer
	       {
		 RGBdata[j*LL*3+i*3+0]=85;
		 RGBdata[j*LL*3+i*3+1]=85;
		 RGBdata[j*LL*3+i*3+2]=200;
	       }
	  	 else if(CColour[i][j]==5) //xylem nearly done
	  	   {
		 RGBdata[j*LL*3+i*3+0]=50;
		 RGBdata[j*LL*3+i*3+1]=50;
		 RGBdata[j*LL*3+i*3+2]=180;
	       }
	  	 else if(CColour[i][j]==6) //final xylem
	  	   {
		 RGBdata[j*LL*3+i*3+0]=0;
		 RGBdata[j*LL*3+i*3+1]=0;
		 RGBdata[j*LL*3+i*3+2]=100;
	       }	       	       
	     else if(CColour[i][j]==7)//dividing cell leaning to phloem
	       {
		 RGBdata[j*LL*3+i*3+0]=130;
		 RGBdata[j*LL*3+i*3+1]=254;
		 RGBdata[j*LL*3+i*3+2]=130;
	       }
	     else if(CColour[i][j]==8)//nondividing cell leaning to phloem
	       {
		 RGBdata[j*LL*3+i*3+0]=70;
		 RGBdata[j*LL*3+i*3+1]=210;
		 RGBdata[j*LL*3+i*3+2]=70;
	       }
	       
	       
	     else if(CColour[i][j]==9)//committed phloem
	       {
		 RGBdata[j*LL*3+i*3+0]=10;
		 RGBdata[j*LL*3+i*3+1]=150;
		 RGBdata[j*LL*3+i*3+2]=10;
	       }
		 else if(CColour[i][j]==10)//phloem done
	       {
		 RGBdata[j*LL*3+i*3+0]=0;
		 RGBdata[j*LL*3+i*3+1]=100;
		 RGBdata[j*LL*3+i*3+2]=0;
	       }       
		 else if(CColour[i][j]==254){//white
		 RGBdata[j*LL*3+i*3+0]=254;
		 RGBdata[j*LL*3+i*3+1]=254;
		 RGBdata[j*LL*3+i*3+2]=254;	 
	       }      
	   }
     }

  PNGFileP = fopen(fname, "wb");
  png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING,(png_voidp) NULL,
                    (png_error_ptr) NULL,
                    (png_error_ptr) NULL );
  if(!png_ptr){
    printf("out of memory\n");
    exit(1);
  }
  info_ptr = png_create_info_struct ( png_ptr );
  if(!info_ptr){
    png_destroy_write_struct(&png_ptr, NULL);
    printf("out of memory\n");
    exit(1);
  }
  png_init_io ( png_ptr, PNGFileP );
  png_set_IHDR(png_ptr, info_ptr,LL,WW,
           8, PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE,
           PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
  png_write_info ( png_ptr, info_ptr );
  /*write out image, one row at a time*/
  int row;
  for(row = WW-1; row >= 0; row--){
    row_pointer = ( RGBdata + LL * row * 3 );
    png_write_rows ( png_ptr, &row_pointer, 1 );
  }
  png_write_end ( png_ptr, info_ptr );
  fflush ( PNGFileP );
  png_destroy_write_struct ( &png_ptr,&info_ptr);
  fclose(PNGFileP);
}  
