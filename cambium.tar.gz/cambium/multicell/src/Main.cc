/*

DigitalRoot simulates the regulation of root growth and developmental 
zonation by the phytohormone auxin and the PLETHORA transcription factors  
in a simplified, two dimensional model of the Arabidopsis root.

Copyright 2012-2014, Kirsten ten Tusscher


DigitalRoot is distributed under the terms of the GNU General Public 
License.


DigitalRoot is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

DigitalRoot is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with DigitalRoot.  If not, see <http://www.gnu.org/licenses/>.

*/
#include "Param_config.hh"
#include "Basic_params.hh"
#include "Functions.hh"
#include "Arrays.hh"
#include "Plant_layout.hh"



char dirname[2000];
int actcells;
int phloemcounter = 0;
int xylemcounter=0;
double auxmax;
double globalCLEprod;


//Grid based properties
int Tc[n][m];
int **Tmt;


//Cell based properties
int Cell[n][m];
int CellSizes[totcells];
double InvCellSizes[totcells];
int CellMinI[totcells];
int CellMinJ[totcells];
int CellMaxI[totcells];
int CellMaxJ[totcells];
int CellWidth[totcells];
int CellHeight[totcells];


int CellZonationState[totcells];
double ARF[totcells];
double Plts[totcells];
double HDZIP3[totcells];
double ANT[totcells];
double CLE41[totcells];
double PXY[totcells];
double PXYbound[totcells];


void MakeArrays()
{

  int i,j,k;

  
  for(i=0;i<n;i++)
    for(j=0;j<m;j++)
      Tc[i][j]=0;
  //Tmt
  if (( Tmt = new int*[n]) == NULL )
    { printf("error in allocating Tmt array\n"); exit(1);}
  for ( i = 0; i < n; i++ )
    {
      if (( Tmt[i] = new int[m]) == NULL )
	{ printf("error in allocating Tmt array\n"); exit(1);}
    }
  for(i=0;i<n;i++)
    for(j=0;j<m;j++)
      Tmt[i][j]=0;

}

void FreeArrays()

{
  int i,j;
  for(i = 0; i < n; i++)
    delete[] Tmt[i];
  delete[] Tmt;
}
  


void Start(int argc, char **argv)
{
  if(argc<2)
    {
      printf("usage: exc dirname\n");
      exit(1);
    }
  else
    {
      strcpy(dirname,argv[1]);
    }
}



int single_run(int argc)
{
  double dummypict[n][m];
  int time;
  int i,j,q,k;
  int starttime;
  MakeArrays();
  SetUpMembraneTypes();
  starttime=0;
  InitPlant();

 for(time=starttime;time<=maxnrsteps;time++)
   {
     
     //do the actual calculations on the dynamics of the regulatory network
     if(time%speedup2==0)
       {
	 UpdateGeneExpression((int)(time*tstep));
       }

     //make a dump of the state of the simulated tissue to allow restart from this point
     if((int)(time*tstep)>0 && (int)(time*tstep)%50000==0)
	WritePlantToFile((int)(time*tstep));

     
     //saving output figures and files
     if(time% tsave   ==0)
	{

	   for(q=0;q<actcells;q++)
	    {
	      SaveTemp((int)(time*tstep),(int)(0.5*(CellMinI[q]+CellMaxI[q])),(int)(0.5*(CellMinJ[q]+CellMaxJ[q])));
	    }


	 
	  //for png pictures we need double values
	  //dummyarray is uded tp go from int to double
	  for(i=0;i<n;i++)
	    for(j=0;j<m;j++)
	      dummypict[i][j]=Tc[i][j];
	  MakePNGFile(dirname,dummypict,(int)(time*tstep),0);

	  
	  //for png we also need values at grid level instead of cell level
	  //here we use a function to project cell level to grid level values
	  //before calling the MakePNGFile function within this function
	  prepare_Int_PNG(CellZonationState,9,(int)(time*tstep),dirname);
	  prepare_PNG(PXY,10,(int)(time*tstep),dirname);
	  prepare_PNG(PXYbound,15,(int)(time*tstep),dirname);
	  prepare_PNG(CLE41,11,(int)(time*tstep),dirname);
	  prepare_PNG(ANT,12,(int)(time*tstep),dirname);
	  prepare_PNG(HDZIP3,13,(int)(time*tstep),dirname);
	  prepare_PNG(ARF,3,(int)(time*tstep),dirname);
	  prepare_PNG(Plts,4,(int)(time*tstep),dirname);
	  prepare_Int_PNG(CellZonationState,14,(int)(time*tstep),dirname);
	  //to make a picture combining the above separate pictures
	  make_combined_figure(dirname,(int)(time*tstep));
	   
	}
    }
 FreeArrays();
 return 0;
}



int main(int argc, char **argv)
 {
   auxmax = auxmax_min;
   globalCLEprod = globalCLEprod_min;
   Start(argc,argv);
   single_run(argc);
   return 0;
 }
