/*

DigitalRoot simulates the regulation of root growth and developmental 
zonation by the phytohormone auxin and the PLETHORA transcription factors  
in a simplified, two dimensional model of the Arabidopsis root.

Copyright 2012-2014, Kirsten ten Tusscher


DigitalRoot is distributed under the terms of the GNU General Public 
License.


DigitalRoot is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

DigitalRoot is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with DigitalRoot.  If not, see <http://www.gnu.org/licenses/>.

*/
#include "Param_config.hh"
#include "Basic_params.hh"
#include "Functions.hh"
#include "Arrays.hh"
#include "Plant_layout.hh"


void SaveTemp(int t,int II,int JJ)
{
  FILE *f;					
  char s[1000];
  int q;

  q=Cell[II][JJ];
  sprintf(s,"%s/TemporalDynamicsPoint%i_%i",dirname,II,JJ);
  f=fopen(s,"a");
  fprintf(f,"%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f \n",(((double)t)/3600.0),ARF[q],HDZIP3[q],PXY[q],CLE41[q],PXYbound[q],PXY[q]+PXYbound[q],CLE41[q]+PXYbound[q],Plts[q],ANT[q],Plts[q]+ANT[q]);
  fclose(f);
}



