/*

DigitalRoot simulates the regulation of root growth and developmental 
zonation by the phytohormone auxin and the PLETHORA transcription factors  
in a simplified, two dimensional model of the Arabidopsis root.

Copyright 2012-2014, Kirsten ten Tusscher


DigitalRoot is distributed under the terms of the GNU General Public 
License.


DigitalRoot is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

DigitalRoot is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with DigitalRoot.  If not, see <http://www.gnu.org/licenses/>.

*/
#include "Param_config.hh"
#include "Basic_params.hh"
#include "Functions.hh"
#include "Arrays.hh"
#include "Plant_layout.hh"

void InitPlant()
{
  SetUpTissueLayout();
  NumberCells();
  FindCellCorners();
  FindCellSizes();
  InitConditions();
}



void NumberCells()
{
  int i,j;
  int q=0;

  for(i=0;i<n;i++)
    for(j=0;j<m;j++)
      Cell[i][j]=-1;

  for(j=0;j<m;j++)
    for(i=0;i<n;i++)
	{
	  if(Tc[i][j]==2 || Tc[i][j]==1)//cell membrane or cytosol
	    {
	      //is it first grid point of cell that is detected
	      if((Cell[i-1][j]==-1 && Cell[i][j-1]==-1)&&
		 (Cell[i+1][j]==-1 && Cell[i][j+1]==-1))
		{
		  Cell[i][j]=q;
		  q++;
		}
	      else
		{
		  if(Cell[i-1][j]!=-1)
		    Cell[i][j]=Cell[i-1][j];
		  else if(Cell[i][j-1]!=-1)
		    Cell[i][j]=Cell[i][j-1];
		  else if(Cell[i+1][j]!=-1)
		    Cell[i][j]=Cell[i+1][j];
		   else if(Cell[i][j+1]!=-1)
		    Cell[i][j]=Cell[i][j+1];
		}
	    }
	}

  actcells=q;
}

void FindCellCorners()
{
  int i,j,q;

  //find mini,maxi,minj,maxj,width,height of cells
  for(q=0;q<totcells;q++)
    {
      CellMinI[q]=10000;
      CellMinJ[q]=10000;
      CellMaxI[q]=0;
      CellMaxJ[q]=0;
      CellWidth[q]=0;
      CellHeight[q]=0;
    }
  for(i=0;i<n;i++)
    for(j=0;j<m;j++)
      {
	q=Cell[i][j];
	if(q!=-1)
	  {
	    if(i<CellMinI[q])
	      CellMinI[q]=i;
	    else if(i>CellMaxI[q])
	      CellMaxI[q]=i;
	    if(j<CellMinJ[q])
	      CellMinJ[q]=j;
	    else if(j>CellMaxJ[q])
	      CellMaxJ[q]=j;
	  }
      }
  for(q=0;q<actcells;q++)
    {
      CellWidth[q]=CellMaxI[q]-CellMinI[q]+1;
      CellHeight[q]=CellMaxJ[q]-CellMinJ[q]+1;
    }
}


void FindCellSizes()
{
  int i,j,q;
  
  //clean arrays
  for(q=0;q<totcells;q++)
    {
      CellSizes[q]=0;
      InvCellSizes[q]=0;
    }
  
  //sla de grootte op van alle cellen  
  for(i=0;i<n;i++)
    for(j=0;j<m;j++)
      {
	if(Cell[i][j]>=0)
	  CellSizes[Cell[i][j]]++;
	}
  
  for(q=0;q<actcells;q++)
    InvCellSizes[q]=1.0/(double)CellSizes[q];
}


