/*

DigitalRoot simulates the regulation of root growth and developmental 
zonation by the phytohormone auxin and the PLETHORA transcription factors  
in a simplified, two dimensional model of the Arabidopsis root.

Copyright 2012-2014, Kirsten ten Tusscher


DigitalRoot is distributed under the terms of the GNU General Public 
License.


DigitalRoot is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

DigitalRoot is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with DigitalRoot.  If not, see <http://www.gnu.org/licenses/>.

*/
#include "Param_config.hh"
#include "Basic_params.hh"
#include "Functions.hh"
#include "Arrays.hh"
#include "Plant_layout.hh"


char dirname[9000];
int actcells;
//sweeping parameters
double auxmax;
double globalCLEprod;


double PXYKMPLTS;
double auxkmPXY;
double PltsKMPXY;
double PltsfacPXY;
double PXYKMANT;
double AuxinKMANT;
double ANTHDZIPfac;
double HDZIPKMANT;
double AuxKMHDZIP;



//Grid based properties
int Tc[n][m];
int **Tmt;



//Cell based properties
int Cell[n][m];
int CellSizes[totcells];
double InvCellSizes[totcells];
int CellMinI[totcells];
int CellMinJ[totcells];
int CellMaxI[totcells];
int CellMaxJ[totcells];
int CellWidth[totcells];
int CellHeight[totcells];
int CellZonationState[totcells];
double ARF[totcells];
double Plts[totcells];
double HDZIP3[totcells];
double ANT[totcells];
double CLE41[totcells];
double PXY[totcells];
double PXYbound[totcells];



void MakeArrays()
{

  int i,j,k;            	

  for(i=0;i<n;i++)
    for(j=0;j<m;j++)
      Tc[i][j]=0;
  //Tmt
  if (( Tmt = new int*[n]) == NULL )
    { printf("error in allocating Tmt array\n"); exit(1);}
  for ( i = 0; i < n; i++ )
    {
      if (( Tmt[i] = new int[m]) == NULL )
	{ printf("error in allocating Tmt array\n"); exit(1);}
    }
  for(i=0;i<n;i++)
    for(j=0;j<m;j++)
      Tmt[i][j]=0;
}

void FreeArrays()
{
  int i,j;

  for(i = 0; i < n; i++)
    delete[] Tmt[i];
  delete[] Tmt;
}
  

void Start(int argc, char **argv)
{
  if(argc<2)
    {
      printf("usage: exc dirname\n");
      exit(1);
    }
  else
    {
      strcpy(dirname,argv[1]);
    }
}


int single_run(int argc)
{
  double dummypict[n][m];
  int time;
  int i,j,q,k;
  int starttime;

  SetUpMembraneTypes();
#ifndef RESTART
  starttime=0;
  InitPlant();
#else
  starttime=givenstart;
  InitPlantFromFile(starttime);
  starttime=(int)(starttime/tstep);
#endif

    
  for(time=starttime;time<=maxnrsteps;time++)
    {
	  

      if(time%speedup2==0)
	{
#ifdef GENEEXPRESSION
	  UpdateGeneExpression((int)(time*tstep));
#endif
	}
      

#ifndef SIMPLEPLOT
      if((int)(time*tstep)>0 && (int)(time*tstep)%50000==0)
	WritePlantToFile((int)(time*tstep));
      
      if(time%tsave==0)
	{
	  
	  for(q=0;q<actcells;q++)
	    {
	      SaveTemp((int)(time*tstep),(int)(0.5*(CellMinI[q]+CellMaxI[q])),(int)(0.5*(CellMinJ[q]+CellMaxJ[q])));
	    }
	  
	  //for png pictures we need double values
	  //dummyarray is uded tp go from int to double
	  for(i=0;i<n;i++)
	    for(j=0;j<m;j++)
	      dummypict[i][j]=Tc[i][j];
	  MakePNGFile(dirname,dummypict,(int)(time*tstep),0);

	  
	  //for png we also need values at grid level instead of cell level
	  //here we use a function to project cell level to grid level values
	  //before calling the MakePNGFile function within this function
	  prepare_Int_PNG(CellZonationState,9,(int)(time*tstep),dirname);
	  prepare_PNG(PXY,10,(int)(time*tstep),dirname);
	  prepare_PNG(PXYbound,15,(int)(time*tstep),dirname);
	  prepare_PNG(CLE41,11,(int)(time*tstep),dirname);
	  prepare_PNG(ANT,12,(int)(time*tstep),dirname);
	  prepare_PNG(HDZIP3,13,(int)(time*tstep),dirname);
	  prepare_PNG(ARF,3,(int)(time*tstep),dirname);
	  prepare_PNG(Plts,4,(int)(time*tstep),dirname);
	  prepare_Int_PNG(CellZonationState,14,(int)(time*tstep),dirname);


	  //to make a picture combining the above separate pictures
	  make_combined_figure(dirname,(int)(time*tstep));


	  Trackcontentfirst(time*tstep);
	  Trackcontentsecond(time*tstep);
	 
	}
#else
      if(time%tsave==0 && time>1000)
	{ 
	  // Trackcontentfirstsweep(time*tstep);
	  Trackcontentsecondsweep(time*tstep); //simplified output for sweep //WHERE IS THIS FUNCTION?
	}
#endif
    }  

  return 0;
}


//vary auxin and TDIF values
int multimain(int argc, char **argv)
{

 char s[9000];

 cout << "auxmaxes min" <<auxmax_min << " max "<< auxmax_maxsize << " step " <<auxmax_stepsize<<std::endl;

 std::string basedirname = dirname;
 for(auxmax = auxmax_min;auxmax<auxmax_maxsize;auxmax+=auxmax_stepsize)
   {
     for(globalCLEprod = globalCLEprod_min;globalCLEprod < globalCLEprod_maxsize; globalCLEprod+=globalCLEprod_stepsize)
       {
	 char s[3000];
	 char auxname[3000];
	 sprintf(auxname,"%.1f",auxmax);
	 char CLEname[3000];
	 sprintf(CLEname,"%.4f",globalCLEprod);
	 std::string newdirname = std::string(basedirname) +std::string("//auxinmax_")+ std::string(auxname)+ std::string("CLEprod_")+std::string(CLEname);
	 cout << "newdirname " << newdirname <<std::endl;
	 strcpy(dirname,newdirname.c_str());
	 sprintf(s,"mkdir %s",dirname);
	 system(s);
	 cout << "params " << PXYKMPLTS << " " <<auxkmPXY << " " <<  PltsKMPXY << " "<< PltsfacPXY << " "<< PXYKMANT << " " << AuxinKMANT  << " "<< ANTHDZIPfac << " " << AuxKMHDZIP<< std::endl;
	 
	 single_run(argc);
       }
   }
 return 0;
}


//single run so no intricate directory structure.
 int singlemain(int argc, char **argv)
{
 auxmax = auxmax_min;
 globalCLEprod = globalCLEprod_min;
 single_run(argc);
 return 0;
}

int sweepmain(int argc, char **argv)
{
	
  char s[9000];
  std::string baseDirname= std::string(dirname)+"/";
  for(PXYKMPLTS = PXYKMPLTSmin;PXYKMPLTS<=PXYKMPLTSmax;PXYKMPLTS+=(PXYKMPLTSmax-PXYKMPLTSmin)/PXYKMPLTSstep)//1
    {
      char PXKPL[20];
      sprintf(PXKPL,"%.1f",PXYKMPLTS);
      std::string PXYKMPLTSname = std::string(baseDirname)+std::string("PXKPL")+ std::string(PXKPL)+std::string("/");
      strcpy(dirname,PXYKMPLTSname.c_str());
      sprintf(s,"mkdir %s",dirname);
      system(s);
      std::string base1Dirname = dirname;
    
      for(auxkmPXY = auxkmPXYmin;auxkmPXY<=auxkmPXYmax;auxkmPXY+=(auxkmPXYmax-auxkmPXYmin)/auxkmPXYstep)//2
	{
	  char AUKPX[20];
	  sprintf(AUKPX,"%.1f",auxkmPXY);
	  std::string PXYKMPLTSname =  std::string(base1Dirname)+std::string("AUKPX")+ std::string(AUKPX)+std::string("/");
	  strcpy(dirname,PXYKMPLTSname.c_str());
	  sprintf(s,"mkdir %s",dirname);
	  system(s);
	  std::string base2Dirname = dirname;
	  
	  for(PltsKMPXY = PltsKMPXYmin;PltsKMPXY<=PltsKMPXYmax;PltsKMPXY+=(PltsKMPXYmax-PltsKMPXYmin)/PltsKMPXYstep)//3
	    {
	      char PLKPX[20];
	      sprintf(PLKPX,"%.1f",PltsKMPXY);
	      std::string PltsKMPXYname = std::string(base2Dirname)+std::string("PLKPX")+ std::string(PLKPX)+std::string("/");
	      strcpy(dirname,PltsKMPXYname.c_str());
	      sprintf(s,"mkdir %s",dirname);
	      system(s);
	      std::string base3Dirname = dirname;

	      for(PltsfacPXY = PltsfacPXYmin;PltsfacPXY<=PltsfacPXYmax;PltsfacPXY+=(PltsfacPXYmax-PltsfacPXYmin)/PltsfacPXYstep)//4
		{
		  char PLFPX[20];
		  sprintf(PLFPX,"%.2f",PltsfacPXY);
		  std::string PltsfacPXYname = std::string(base3Dirname)+std::string("PLFPX")+ std::string(PLFPX)+std::string("/");
		  strcpy(dirname,PltsfacPXYname.c_str());
		  sprintf(s,"mkdir %s",dirname);
		  system(s);
		  std::string base4Dirname = dirname;
          
		  for(PXYKMANT = PXYKMANTmin;PXYKMANT<=PXYKMANTmax+1;PXYKMANT+=(PXYKMANTmax-PXYKMANTmin)/PXYKMANTstep)//5
		    {
		      char PXKAN[20];
		      sprintf(PXKAN,"%.f",PXYKMANT);
		      std::string PXYKMANTname = std::string(base4Dirname)+std::string("PXKAN")+ std::string(PXKAN)+std::string("/");
		      strcpy(dirname,PXYKMANTname.c_str());
		      sprintf(s,"mkdir %s",dirname);
		      system(s);
		      std::string base5Dirname = dirname;
	        
		      for(AuxinKMANT = AuxinKMANTmin;AuxinKMANT<=AuxinKMANTmax+1;AuxinKMANT+=(AuxinKMANTmax-AuxinKMANTmin)/AuxinKMANTstep)//6
			{
			  char AuKAN[20];
			  sprintf(AuKAN,"%.1f",AuxinKMANT);
			  std::string AuxinKMANTname = std::string(base5Dirname)+std::string("AuKAN")+ std::string(AuKAN)+std::string("/");
			  strcpy(dirname,AuxinKMANTname.c_str());
			  sprintf(s,"mkdir %s",dirname);
			  system(s);
			  std::string base6Dirname = dirname;
              
			  for(ANTHDZIPfac = ANTHDZIPfacmin;ANTHDZIPfac<=ANTHDZIPfacmax+0.01;ANTHDZIPfac+=(ANTHDZIPfacmax-ANTHDZIPfacmin)/ANTHDZIPfacstep)//7
			    {
			      char ANFHD[20];
			      sprintf(ANFHD,"%.2f",ANTHDZIPfac);
			      std::string ANTHDZIPfacname = std::string(base6Dirname)+std::string("ANFHD")+ std::string(ANFHD)+std::string("/");
			      strcpy(dirname,ANTHDZIPfacname.c_str());
			      sprintf(s,"mkdir %s",dirname);
			      system(s);
			      std::string base7Dirname = dirname;

			      for(HDZIPKMANT = HDZIPKMANTmin;HDZIPKMANT<=HDZIPKMANTmax+1;HDZIPKMANT+=(HDZIPKMANTmax-HDZIPKMANTmin)/HDZIPKMANTstep)//8
				{
				  char HDKAN[20];
				  sprintf(HDKAN,"%.1f",HDZIPKMANT);
				  std::string HDZIPKMANTame = std::string(base7Dirname)+std::string("HDKAN")+ std::string(HDKAN)+std::string("/");
				  strcpy(dirname,HDZIPKMANTame.c_str());
				  sprintf(s,"mkdir %s",dirname);
				  system(s);
				  std::string base8Dirname = dirname;             
                
				  for(AuxKMHDZIP = AuxKMHDZIPmin;AuxKMHDZIP<=AuxKMHDZIPmax+1;AuxKMHDZIP+=(AuxKMHDZIPmax-AuxKMHDZIPmin)/AuxKMHDZIPstep)//9
				    {
				      char AuKHD[20];
				      sprintf(AuKHD,"%.1f",AuxKMHDZIP);
				      std::string AuxKMHDZIPcname = std::string(base8Dirname)+std::string("AuKHD")+ std::string(AuKHD);
				      strcpy(dirname,AuxKMHDZIPcname.c_str());
				      //sprintf(s,"mkdir %s",dirname);
				      //system(s);
				      std::string base9Dirname = dirname;
				      // multimain(argc, argv);
				      cout << base9Dirname << std::endl;
				      for(auxmax = auxmax_min;auxmax<auxmax_maxsize;auxmax+=auxmax_stepsize){
					for(globalCLEprod = globalCLEprod_min;globalCLEprod < globalCLEprod_maxsize; globalCLEprod+=globalCLEprod_stepsize){
		  		          single_run(argc);
				     }
			       }
			     }
               }
             }
           }
         }
       }
     }
   }
 }
 cout << "Finished full set " << std::endl;
 return 0;
}




int main(int argc, char **argv)
{

  Start(argc,argv);
  MakeArrays();

#ifdef PARAMSWEEP
  sweepmain(argc,argv);//vary 9 parameters AND auxin and TDIF
#else
#ifdef MULTIRUN
  multimain(argc,argv);//vary auxin and TDIF
#else
  singlemain(argc,argv);//single value auxin and TDIF
#endif
#endif
 FreeArrays();
 return 0;
}
