/*

DigitalRoot simulates the regulation of root growth and developmental 
zonation by the phytohormone auxin and the PLETHORA transcription factors  
in a simplified, two dimensional model of the Arabidopsis root.

Copyright 2012-2014, Kirsten ten Tusscher


DigitalRoot is distributed under the terms of the GNU General Public 
License.


DigitalRoot is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

DigitalRoot is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with DigitalRoot.  If not, see <http://www.gnu.org/licenses/>.

*/
#ifndef GeneralHeader
#define GeneralHeader
#include <string>
#include <tuple>
using namespace std;


#include <ctype.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <png.h>

//note that for the strong sequestration settings
//because of the slow TDIF-PXY unbinding rate 
//a smaller timestep of 0.2 is necessary
#define tstep 0.85 //timestep of integration for GRN dynamics in seconds
#define speedup2 1   //factor with which timestep of integration for other dynamics is larger
                      
#define tmax 3600*12*5 // *2.5 //*5 total runtime of simulation
#define maxnrsteps (int)(tmax/tstep)//total nr of update steps in simulation
#define tsave (int)((3600*2)/tstep) //interval at which output will be saved
const double xstep=2; //spacestep of integration for grid based properties

/************************************************************************************************/

//general parameters
extern char dirname[2000];


#endif
