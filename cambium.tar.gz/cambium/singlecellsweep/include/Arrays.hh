/*

DigitalRoot simulates the regulation of root growth and developmental 
zonation by the phytohormone auxin and the PLETHORA transcription factors  
in a simplified, two dimensional model of the Arabidopsis root.

Copyright 2012-2014, Kirsten ten Tusscher


DigitalRoot is distributed under the terms of the GNU General Public 
License.


DigitalRoot is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

DigitalRoot is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with DigitalRoot.  If not, see <http://www.gnu.org/licenses/>.

*/
#ifndef FunctionHeader
#define FunctionHeader

using namespace std;

#include <array>
#include <ctype.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <png.h>


//extern char dirname[2000];


//Grid based properties
extern int Tc[n][m];
extern int **Tmt;

//Cell based properties
extern int Cell[n][m];
extern int CellSizes[totcells];
extern double InvCellSizes[totcells];
extern int CellMinI[totcells];
extern int CellMinJ[totcells];
extern int CellMaxI[totcells];
extern int CellMaxJ[totcells];
extern int CellWidth[totcells];
extern int CellHeight[totcells];
extern int CellZonationState[totcells];


extern double HDZIP3[totcells];
extern double ANT[totcells];
extern double CLE41[totcells];
extern double PXY[totcells];
extern double PXYbound[totcells];
extern double ARF[totcells];
extern double Plts[totcells];


#endif
