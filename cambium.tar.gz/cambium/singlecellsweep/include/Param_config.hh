#ifndef ConfigHeader
#define ConfigHeader

using namespace std;

#include "Basic_params.hh"
#include "Plant_layout.hh"
#include <cstring>

//Below the #define XXX statements allow you to switch between
//different types of conditions to be simulated
//To "activate" a define statement uncomment it (no // in front)
//to "inactivate a define statement comment it (// in front)




#define  HDZIPFULLEFF //both auxin and TDIF-PXY induced part of ANT can be
//repressed by HDZIP3 (only switched off in multicellular strong sequestration settings)
// #define  EXPLICITPXYBINDING//if TDIF binds to PXY amount of TDIF to freely diffuse
//declines (only swiched on in multicellular strong sequestration settings)

#define PARAMSWEEP
#define SIMPLEPLOT //this suppresses making some  files, which would become massive for a 9dimensional parameter sweep

extern double sweepresults[11][6][3];
extern long sweepcounter;
extern char maindirname[2000];

extern double sweepHDZIP3[11][6];
extern double sweepPLTANT[11][6];
extern double sweepPXY[11][6];
extern double sweepCLEPXY[11][6];

extern double auxmax;
const double auxmax_min = 0;//lower bound for auxin in auxin X TDIF exposure matrix
const double auxmax_stepsize = 10.;//increment size
const double auxmax_maxsize = 101;//upper bound for auxin in auxin X TDIF exposure matrix
// so auxin is varied 0  to 100 in 11 steps


extern double globalCLEprod;
const double globalCLEprod_min =0.;//lower bound for TDIF production in auxin X TDIF exposure matrix
const double globalCLEprod_stepsize= 0.004;//increment size
const double globalCLEprod_maxsize = 0.02002;//upper bound for TDIF production in auxin X TDIF exposure matrix
//so, given decay rate, TDIF is varied  from 0 to 100 in 6 steps
const double extraCLEprod = 0.00;


#define LOWERAUXUNDIF


//PLT plasmodesmatal flux rate 
const double pdflux=0.04/(double)xstep;


//auxin parameters:
const double auxdelay = 0.01;


//Gene expression parameters
const double maxPlts=0.02;//0.025 with diffusion to other cells.
const double decayPlts=0.0002;
const double pltsfac=1.;
const double pltsdiff = 0.00002;
extern double PXYKMPLTS; //is being varied for sweep //1 //corresponds to K_c,p
const double PXYKMPLTSstep = 10;// 5.0;//step size for sweep 
const double PXYKMPLTSmin = 20; //min value for sweep 
const double PXYKMPLTSmax = 40;//max value sweep 
const double PXYkmPLTpwr = 2;

const double maxPXY= 0.12;
const double decayPXY = 0.0012;
extern double auxkmPXY; //is being varied in sweep //2 //corresponds to K_a,X             
const double auxkmPXYstep = 10;// 5.0;//step size for sweep 
const double auxkmPXYmin = 15; //min value sweep 
const double auxkmPXYmax = 35;//max value sweep
const double auxkmPXYpwr= 2;

extern double PltsKMPXY;//is being varied in sweep //3 //corresponds to K_P,X
const double PltsKMPXYstep = 10;// 5.0;//step size for sweep  
const double PltsKMPXYmin = 30; //min value sweep 
const double PltsKMPXYmax = 50;//max value sweep 
const double pltskmPXYpwr = 2;

extern double PltsfacPXY;//is being varied in sweep //4 //corresponds to f_P,X
const double PltsfacPXYstep = 0.1;//0.05;//step size for sweep 
const double PltsfacPXYmin = 0.3 ;//min value sweep 
const double PltsfacPXYmax = 0.6 ;//max value sweep
const double targetdegraded = 0.0012;
       


const double maxCLE41= 0.0;
const double decayCLE41 = 0.0002;
const double CLE41diff= 0.02;
const double PXYass = 0.02;
const double PXYdiss = 0.1;


//ANT PARAMETERS
const double maxANT= 0.02;
const double decayANT = 0.0002;
//which fraction of ANT is induced by auxin, 1-fraction is then induced by TDIF-PXY
extern double ANTAuxfac;//m_a,A //use this one for sweep //10
extern double ANTPXYfac;//m_C,A //for this one use 1-ANTAuxfac
const double ANTfacstep=0.1;// 0.05;//step size for sweeps
const double ANTfacmin=0.1;//min value sweep
const double ANTfacmax=0.4;//max value sweep

extern double PXYKMANT;//is being varied in sweep //5 //corresponds to K_C,A 
const double PXYKMANTstep =10;//  5;//step size for sweep
const double PXYKMANTmin = 15;// min value sweep 
const double PXYKMANTmax = 35;//max value sweep
const double PXYkmANTpwr = 2;
extern double AuxinKMANT;//is being varied in sweep //6 //corresponds to K_a,A
const double AuxinKMANTstep = 10;// 5;//step size for sweep
const double AuxinKMANTmin = 15;//min value sweep
const double AuxinKMANTmax = 35;//max value sweep 
const double AuxinkmANTpwr = 2;
//which fraction of ANT can be repressed by HDZIP3
extern double ANTHDZIPfac;//is being varied in sweep //7 //corresponds to r_H,a= r_H,C 
const double ANTHDZIPfacstep = 0.2;// 0.1; //step size for sweep 
const double ANTHDZIPfacmin =  0.4;//min value sweep
const double ANTHDZIPfacmax = 1.0;//max value sweep
extern double HDZIPKMANT;//is being varied in sweep //8 //corresponds to K_H,A
const double HDZIPKMANTstep = 10;// 5;//step size for sweep 
const double HDZIPKMANTmin =  30;//min value sweep
const double HDZIPKMANTmax =  50;//max value sweep
const double HDZIPKMANTpwr = 2;

//HDZIP parameters
const double maxHDZIP3 = 0.03;
const double decayHDZIP3 = 0.0003;
const double facHDZIP3 = 1.0;
extern double AuxKMHDZIP; //is being varied in sweep //9 //corresponds to K_a,H
const double AuxKMHDZIPstep =20;// 10;//step size sweep 
const double AuxKMHDZIPmin = 30;//min value sweep
const double AuxKMHDZIPmax = 70;//max value sweep
const double auxkmhdzippwr = 4;






#endif






