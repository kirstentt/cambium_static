/*

DigitalRoot simulates the regulation of root growth and developmental 
zonation by the phytohormone auxin and the PLETHORA transcription factors  
in a simplified, two dimensional model of the Arabidopsis root.

Copyright 2012-2014, Kirsten ten Tusscher


DigitalRoot is distributed under the terms of the GNU General Public 
License.


DigitalRoot is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

DigitalRoot is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with DigitalRoot.  If not, see <http://www.gnu.org/licenses/>.

*/
#ifndef ArrayHeader
#define ArrayHeader

using namespace std;



//Definitions of functions described in the different .cc files

//Save_plant.cc
void WritePlantToFile(int time);
void InitPlantFromFile(int start);

//Initial_layout.cc
void SetUpTissueLayout();
void SetUpMembraneTypes();

//Localization_functions.cc
void InitPlant();
void NumberCells();
void FindCellCorners();
void FindCellSizes();

//Initial_content.cc
void InitConditions();

//Graphics.cc
double min(double a, double b);
double max(double a, double b);
void MakePNGFile(char *dirname, double C[n][m],int t,int flag);
void prepare_Int_PNG(int content[],int flag,int timestep, char *dirname);
void prepare_PNG(double content[],int flag,int timestep, char *dirname);
void make_combined_figure(char *dirname, int t);

//Plotting.cc
void SaveTemp(int t,int II,int JJ);



//Regulatory_interatctions.cc
void UpdateGeneExpression(int time);

//Cellular_diffusion.cc
void CellularDiffusion(double hormonearray[], double maxvertdiffuse,double maxhordiffuse);

#endif
