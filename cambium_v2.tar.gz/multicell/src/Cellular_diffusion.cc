/*

DigitalRoot simulates the regulation of root growth and developmental 
zonation by the phytohormone auxin and the PLETHORA transcription factors  
in a simplified, two dimensional model of the Arabidopsis root.

Copyright 2012-2014, Kirsten ten Tusscher


DigitalRoot is distributed under the terms of the GNU General Public 
License.


DigitalRoot is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

DigitalRoot is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with DigitalRoot.  If not, see <http://www.gnu.org/licenses/>.

*/
#include "Param_config.hh"
#include "Basic_params.hh"	      
#include "Functions.hh"
#include "Arrays.hh"
#include "Plant_layout.hh"


//cells only do cellulardiffusion with neighboring cells, so there is no loss to an external environment.
//Since the phloem cell is on the edge, it builds up more TDIF and effectively only diffuses towards the xylem.
void CellularDiffusion(double hormonearray[], double maxvertdiffuse,double maxhordiffuse)
{
  //tmt
  //1 up
  //2 down
  //3 in
  //4 out
  
  double hormonegrid1[n][m];
  double hormonegrid2[n][m];

  for(int i=0;i<n;i++){
    for(int j=0;j<m;j++){ 
      if(Cell[i][j]!=-1){
	
	int q=Cell[i][j];
	hormonegrid1[i][j]=hormonearray[q];
	hormonegrid2[i][j]=hormonearray[q];
	
      }
      else{
	hormonegrid1[i][j]=0;
      }
    }
  }

 double vertdiffuse = maxvertdiffuse;
 double latdiffuse = maxhordiffuse;
 for(int i=0;i<n;i++)
   {
     for(int j=0;j<m;j++)
       {
	 
	 vertdiffuse = maxvertdiffuse;
	 latdiffuse = maxhordiffuse;
	 
	 if(Tc[i][j]==2)//mebrane, so point of possible exchange
	   {
	     int currentcell = Cell[i][j];
	     int membranelookup = Tmt[i][j] - 1;
	     if(Tc[i-1][j]==0 )//wall to left, so left membrane
	       {
		 int ii=i-1;
		 while(ii>0 && (i-ii)<4)
		   {
		     ii--;
		     if(Tc[ii][j]==2)//neighbouring membrane found
		       {
			 hormonegrid2[i][j]+= 0.5*latdiffuse*(hormonegrid1[ii][j]-hormonegrid1[i][j]);
			 hormonegrid2[ii][j]+= 0.5*latdiffuse*(hormonegrid1[i][j]-hormonegrid1[ii][j]);
			 break;
		       }
		   }
	       }
	     if(Tc[i+1][j]==0)//wall to right, so right membrane
	       {
		 int ii=i+1;
		 
		 while(ii<n && (ii-i)<4)
		   {
		     ii++;
		     if(Tc[ii][j]==2)//neighbouring membrane found
		       {
			 hormonegrid2[i][j]+= 0.5*latdiffuse*(hormonegrid1[ii][j]-hormonegrid1[i][j]);
			 hormonegrid2[ii][j]+= 0.5*latdiffuse*(hormonegrid1[i][j]-hormonegrid1[ii][j]);
			 break;
		       }
		   }
	       }
	     if(Tc[i][j-1]==0 )//wall above, so apical membrane ???????
	       {
		 int jj=j-1;
		 
		 while(jj>0 && (j-jj)<4)
		   {
		     jj--;
		     if(Tc[i][jj]==2)//neighbouring membrane found
		       {
			 
			 
			 hormonegrid2[i][j]+=0.5*vertdiffuse*(hormonegrid1[i][jj]-hormonegrid1[i][j]);
			 hormonegrid2[i][jj]+=0.5*vertdiffuse*(hormonegrid1[i][j]-hormonegrid1[i][jj]);
			 
			 break;
		       }		 
		   }
	       }
	     if(Tc[i][j+1]==0)//wall below, so basal membrane ?????????
	       {
		 int jj=j+1;
		 
		 while(jj<m && (jj-j)<4)
		   {
		     jj++;
		     if(Tc[i][jj]==2)//neighbouring membrane found
		       {
			 
			 hormonegrid2[i][j]+=0.5*vertdiffuse*(hormonegrid1[i][jj]-hormonegrid1[i][j]);
			 hormonegrid2[i][jj]+=0.5*vertdiffuse*(hormonegrid1[i][j]-hormonegrid1[i][jj]);
			 
			 break;
		       }		 
		   }
	       }
	   }
       }
   }
                       

  //transform back from grid to cellular
  //assumption that within cell PLTs differences
  //even out quickly through diffusion
  for(int q=0;q<totcells;q++)
    hormonearray[q]=0;
  for(int i=0;i<n;i++)
    {
      for(int j=0;j<m;j++)
	{
	  if(Cell[i][j]!=-1)
	    {//cell there
	      int q=Cell[i][j];
	      hormonearray[q]+=hormonegrid2[i][j];
	    }
	}
    } 
  for(int q=0;q<actcells;q++)
    hormonearray[q]*=(double)InvCellSizes[q];

} 



