/*

DigitalRoot simulates the regulation of root growth and developmental 
zonation by the phytohormone auxin and the PLETHORA transcription factors  
in a simplified, two dimensional model of the Arabidopsis root.

Copyright 2012-2014, Kirsten ten Tusscher


DigitalRoot is distributed under the terms of the GNU General Public 
License.


DigitalRoot is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

DigitalRoot is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with DigitalRoot.  If not, see <http://www.gnu.org/licenses/>.

*/
#include "Param_config.hh"
#include "Basic_params.hh"
#include "Functions.hh"
#include "Arrays.hh"
#include "Plant_layout.hh"


void InitPlantFromFile(int startt)
{
  FILE *f;
  char fname2[800];

  sprintf(fname2,"%s/DumpPlantStateAt%.10d",dirname,startt);
  //sprintf(fname2,"%s/%s",dirname,fname);
  f=fopen(fname2,"rb");
  //tissue architecture and cell numbering
  fread(Tc,sizeof(Tc),1,f);
  fread(Cell,sizeof(Cell),1,f);
 
  //gene expression levels
  fread(ARF,sizeof(ARF),1,f);
  fread(Plts,sizeof(Plts),1,f);
  fread(HDZIP3,sizeof(HDZIP3),1,f);
  fread(ANT,sizeof(ANT),1,f);
  fread(CLE41,sizeof(CLE41),1,f);
  fread(PXY,sizeof(PXY),1,f);
  fread(PXYbound,sizeof(PXYbound),1,f);
  
  //miscelleanous
  fread(CellZonationState,sizeof(CellZonationState),1,f);
  //nr of cells
  fread(&actcells,sizeof(actcells),1,f);
  fclose(f);
  FindCellCorners();
  FindCellSizes();
 
  //cell size related parameters
  fread(CellWidth,sizeof(CellWidth),1,f);
  fread(CellHeight,sizeof(CellHeight),1,f);
}



void WritePlantToFile(int time)
{
  FILE *f;
  char fname[800];
  sprintf(fname,"%s/DumpPlantStateAt%.10d",dirname,time);
  f=fopen(fname,"wb");

  //tissue architecture and cell numbering
  fwrite(Tc,sizeof(Tc),1,f);
  fwrite(Cell,sizeof(Cell),1,f);
  //gene expression levels
  fwrite(ARF,sizeof(ARF),1,f);
  fwrite(Plts,sizeof(Plts),1,f);
  fwrite(HDZIP3,sizeof(HDZIP3),1,f);
  fwrite(ANT,sizeof(ANT),1,f);
  fwrite(CLE41,sizeof(CLE41),1,f);
  fwrite(PXY,sizeof(PXY),1,f);
  fwrite(PXYbound,sizeof(PXYbound),1,f);
  
  //miscelleanous
  fwrite(CellZonationState,sizeof(CellZonationState),1,f);
  //nr of cells
  fwrite(&actcells,sizeof(actcells),1,f);
  
  //cell size related parameters
  fread(CellWidth,sizeof(CellWidth),1,f);
  fread(CellHeight,sizeof(CellHeight),1,f);
 
  fclose(f);

}


