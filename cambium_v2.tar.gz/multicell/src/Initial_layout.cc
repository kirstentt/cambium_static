/*

DigitalRoot simulates the regulation of root growth and developmental 
zonation by the phytohormone auxin and the PLETHORA transcription factors  
in a simplified, two dimensional model of the Arabidopsis root.

Copyright 2012-2014, Kirsten ten Tusscher


DigitalRoot is distributed under the terms of the GNU General Public 
License.


DigitalRoot is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

DigitalRoot is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with DigitalRoot.  If not, see <http://www.gnu.org/licenses/>.

*/
#include "Param_config.hh"
#include "Basic_params.hh"
#include "Functions.hh"
#include "Arrays.hh"
#include "Plant_layout.hh"

void SetUpTissueLayout()
{
  int initialheight = Y1 *(M1+1) +Y2 *(M2+1) + Y3* (M3+1) + Y4* (M4+1)+ Y5* (M5+1) ;
  int  beginy = int(float(m)/2.) - int((float)initialheight/2.) ;
  int i,j,k;

  //first make part of simulation domain you do not need in j direction non tissue, rest tissue
  for(i=0;i<n;i++){
    for(j=0;j<m;j++)
      {
	if (j<beginy){
	  Tc[i][j]=3;//external, non-tissue

	}
	else if(j<=(beginy+initialheight-1)){
	  Tc[i][j]=1;//default cytosol
	}
	else{
	  Tc[i][j]=3;//external, non-tissue
      }
    }
  }
  //next put in the cell walls
  //horizontally oriented wall portions
  for(i=0;i<n;i++)
    for(j=beginy;j<m-bufsize;j++)
      {
	if(j-beginy<z1)
	  Tc[i][j]=0;
	else if(j-beginy>m-1-z1-bufsize)
	  Tc[i][j]=0;
	else
	  {
	    int temp;
	    
	    for(k=1;k<=Y1;k++)//Xylem
	      {
		if(j-beginy>=z1+k*M1+(k-1)*1*z1 && j-beginy<z1+k*M1+(k-1)*1*z1+1)
		  Tc[i][j]=0;
	      }
	    temp=z1+Y1*M1+Y1*1*z1;
	    for(k=Y1+1;k<=Y1+Y4;k++)//Xylem organizer
	      {
		if(j-beginy>=temp+(k-Y1)*M4+(k-Y1-1)*1*z1 && 
		   j-beginy<temp+(k-Y1)*M4+(k-Y1-1)*1*z1+1)
		  Tc[i][j]=0;
	      }
	    temp=z1+Y1*M1+Y4*M4+(Y1+Y4)*1*z1;		
	    
	    
	    for(k=Y1+Y4+1;k<=Y1+Y2+Y4;k++)//Cambium
	      {
		if(j-beginy>=temp+(k-Y1-Y4)*M2+(k-Y1-Y4-1)*1*z1 && 
		   j-beginy<temp+(k-Y1-Y4)*M2+(k-Y1-Y4-1)*1*z1+1)
		  Tc[i][j]=0;
	      }
	    temp=z1+Y1*M1+Y2*M2+Y4*M4+(Y1+Y2+Y4)*1*z1;
	    for(k=Y1+Y4+Y2+1;k<=Y1+Y2+Y4+Y5;k++)//Developing phloem
	      {
		if(j-beginy>=temp+(k-Y1-Y4-Y2)*M5+(k-Y1-Y4-Y2-1)*1*z1 && 
		   j-beginy<temp+(k-Y1-Y4-Y2)*M5+(k-Y1-Y4-Y2-1)*1*z1+1)
		  Tc[i][j]=0;
	      }
	    temp=z1+Y1*M1+Y2*M2+Y4*M4+Y5*M5+(Y1+Y2+Y4+Y5)*1*z1;
	    for(k=Y1+Y2+Y4+Y5+1;k<=Y1+Y2+Y3+Y4+Y5;k++)//Phloem
	      {
		if(j-beginy>=temp+(k-Y1-Y2-Y4-Y5)*M3+(k-Y1-Y2-Y4-Y5-1)*1*z1 &&
		   j-beginy<temp+(k-Y1-Y2-Y4-Y5)*M3+(k-Y1-Y2-Y4-Y5-1)*1*z1+1)
		  Tc[i][j]=0;
	      }
	  }
      }  
  //vertically oriented wall portionsX
  for(i=0;i<n;i++)
    for(j=beginy;j<=beginy+initialheight;j++)
      {
	if(i<z1)
	  Tc[i][j]=0;
	else if(i>n-1-z1)
	  Tc[i][j]=0;
      }
  //determine membrane locations: those cell locations next to wall
  for(i=0;i<n;i++)
    for(j=0;j<m-bufsize;j++)
      {
	if(Tc[i][j]==1)//cell
	  {
	    if(Tc[i+1][j]==0 || Tc[i-1][j]==0 || Tc[i][j+1]==0 || Tc[i][j-1]==0)//nb is wall
	      Tc[i][j]=2; //membrane
	  }
      }
}

void SetUpMembraneTypes()
{
  int i,ii,j,jj,q,iii,jjj;
  //determine membrane orientation: 1: top, 2: bottom, 3: in, 4:out
  for(i=0;i<n;i++)
    for(j=0;j<m;j++)
      {
	if(Tc[i][j]==2)
	  Tmt[i][j]=10;//dummy orientation if a membrane
	else
	  Tmt[i][j]=0;//no orientation if not a membrane
      }
  
  for(i=xm;i>=0;i--)
     for(j=0;j<=m;j++)
      {
	ii = n -i-1;
	if(Tmt[i][j]==10)//there is an unidentified membrane
	  {
	    if(j==CellMaxJ[Cell[i][j]])//top
	      {
		Tmt[i][j]=1;
		Tmt[ii][j]=1;
	      }
	    else if(j==CellMinJ[Cell[i][j]])//bottom
	      {
		Tmt[i][j]=2;
		Tmt[ii][j]=2;
	      }
	    else if(Tc[i+1][j]==0)//right
	      {
		Tmt[i][j]=3;
		Tmt[ii][j]=3;
	      }
	    else if(Tc[i-1][j]==0)//left
	      {
		Tmt[i][j]=4;
		Tmt[ii][j]=4;
	      }
	  }
      }
}
