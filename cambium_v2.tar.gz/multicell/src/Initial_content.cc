/*

DigitalRoot simulates the regulation of root growth and developmental 
zonation by the phytohormone auxin and the PLETHORA transcription factors  
in a simplified, two dimensional model of the Arabidopsis root.

Copyright 2012-2014, Kirsten ten Tusscher


DigitalRoot is distributed under the terms of the GNU General Public 
License.


DigitalRoot is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

DigitalRoot is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with DigitalRoot.  If not, see <http://www.gnu.org/licenses/>.

*/
#include "Param_config.hh"
#include "Basic_params.hh"
#include "Functions.hh"
#include "Arrays.hh"
#include "Plant_layout.hh"

void InitConditions()
{
  int i,j,q;

  //set initial gene expression levels:
  for(q=0;q<actcells;q++)
    {
      ARF[q]=0;
      Plts[q]=0;
      HDZIP3[q]=0;
      ANT[q]=0;
      CLE41[q]=0;
      PXY[q]=0;

      //translation of (presumable) celltype (based on orientation in tissue)
      //into CellZonationState value
      //allows positioning of auxin gradient and CLE41 production at right location
      //from fully differentiated xylem via cambium to fully differentiated phloem
      //numbers run from -100 -80 -60 -1 60 100
   

      if(q==0 && Y1>=1)//Xylem
	{
	  Plts[q]=0;
	  CellZonationState[q]=-100;
	}
      else if(q<X*Y1)//in between Xylem and Xylem organizer, not used in this model
	{
	  CellZonationState[q]=-80;
	}
      else if(q< X*(Y1+Y4))//Xylem organizer
	{
	  Plts[q]=0;
	  CellZonationState[q]=-60;
	}
      else if(q< X*(Y1+Y4+Y2))//Cambium
	{
	  Plts[q]=0;
	  CellZonationState[q]=-1;
	}
      else if (q< X*(Y1+Y2+Y3+Y4+Y5-1))//Developing Phloem 
	{
	  Plts[q]=0;
	  CellZonationState[q]=60;
	}
      else //Phloem
	{
	  Plts[q]=0;
	  CellZonationState[q]=100;
	}
      
    }
}

