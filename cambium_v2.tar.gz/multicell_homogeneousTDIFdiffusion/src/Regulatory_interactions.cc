/*

DigitalRoot simulates the regulation of root growth and developmental 
zonation by the phytohormone auxin and the PLETHORA transcription factors  
in a simplified, two dimensional model of the Arabidopsis root.

Copyright 2012-2014, Kirsten ten Tusscher


DigitalRoot is distributed under the terms of the GNU General Public 
License.


DigitalRoot is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

DigitalRoot is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with DigitalRoot.  If not, see <http://www.gnu.org/licenses/>.

*/
#include "Param_config.hh"
#include "Basic_params.hh"
#include "Functions.hh"
#include "Arrays.hh"
#include "Plant_layout.hh"
#include <math.h>


//method that defines auxin gradient. 
std::tuple<double,bool,double,int> defineAuxingradient(int q,int maxQxylem, int t,bool unbrokenxylem, double xylemreduc, int xylemdev)
{
  double localaux = 0;
  if (q <maxQxylem)
    {
      localaux = 0.;
    }
  else if (CellZonationState[q] ==-80&& unbrokenxylem)
    {
#ifdef LOWERAUXUNDIF //if this is defined cells between the xylem organiser and the fully mature xylem cells have a reduced auxin level, 
    //which makes infiltration by TDIF easier as the HDZIPIII levels are lower. 
      if ((q+1<actcells-1)&& (CellZonationState[q+1] <=-40 ))
	localaux = (auxmax - auxmax/10.*(xylemreduc))*.55;
      else  localaux = auxmax - auxmax/10.*(xylemreduc);
#else
      localaux = auxmax - auxmax/10.*(xylemreduc);
#endif
      xylemreduc+=0.05;
      xylemdev+=1;
    }
  else if (CellZonationState[q] ==-60&& unbrokenxylem)
    {
      localaux = auxmax - auxmax/10.*(xylemreduc);
      xylemreduc+=6.;	
      xylemdev+=1.;
    }
  else if (CellZonationState[q] ==-50&& unbrokenxylem && q>0&& CellZonationState[q-1]!=-60 )
    {
#ifdef LOWERAUXUNDIF
    if ( CellHeight[q]>=(int(M2)*2+-2) &&((q+1<actcells-1)&& (CellZonationState[q+1] <=-40 )) )
      localaux = (auxmax - auxmax/10.*(xylemreduc))*.55;
    else  
      localaux = auxmax - auxmax/10.*(xylemreduc);
#else
    localaux = auxmax - auxmax/10.*(xylemreduc);
#endif
    xylemreduc+=0.05;	
    xylemdev+=1;  
  }
  
#ifdef XYLEMINITIALNONGRADIENT // if this is defined xylem initials follow a linear recuction
  else if (CellZonationState[q] ==-30&& unbrokenxylem)
    {
      localaux = auxmax - auxmax/10.*(xylemreduc);
      
      xylemreduc+=3;	
      xylemdev+=1;  
    }
#endif 
#ifndef PHLOEMAUXINGRAD // default behavior ovverides auxin in mature phloem to always be 1. 
  //This makes sure no PXY is expressed in adult phloem cells, which can heavily affect diffusion
  else if (CellZonationState[q]==100)
    localaux = 1.;
#endif
  else
    { //first cell to still be able to divide
      if (unbrokenxylem)
	{
	  localaux = (auxmax-auxmax/10*float(xylemreduc));
	  unbrokenxylem = false;
	}
      else
	{
	  localaux = (auxmax-auxmax/10*float(xylemreduc))/(1.25*(q+1-maxQxylem-xylemdev)*(q+1-maxQxylem-xylemdev));
	}
    }
  

  return std::make_tuple(localaux, unbrokenxylem,xylemreduc,xylemdev);
}



std::tuple<double,double,double,double> updatePXYCLE(int t, int q,double localaux)
{
  double dtPXYbound=0;       
  
  double dtCLE41=0;
  double CLEproduction = 0;
  if (CellZonationState[q]>=50)//i.e. cell is of phloem type
    {
      if (CellZonationState[q]==100) //fully developed phloem cell
	{//extraCLEprod defines the CLE production/influx from mature phloem cells, 0 in our simulations as we do not have developing versus mature phloem cells
	  CLEproduction = maxCLE41+globalCLEprod+extraCLEprod;
	}
      else //developing phloem cell
	{
	  CLEproduction= maxCLE41+globalCLEprod; // CLE production by committed but not yet fully mature phloem cells
	} 
    }
  else//non phloem cells
    {
      CLEproduction= globalCLEprod; // used if we want to ectopically ect TDIF/CLE to all tissues Typically 0 
    }
  
  
  
  double dtPXY =0;
  double auxinindpxy =pow (localaux, auxkmPXYpwr)/(pow (localaux, auxkmPXYpwr)+ pow(auxkmPXY,auxkmPXYpwr));

  //normal: PXY only repressed by Plt
  double pltreprpxy =pow (PltsKMPXY, pltskmPXYpwr)/(pow (PltsKMPXY, pltskmPXYpwr)+ pow(( Plts[q]) ,pltskmPXYpwr));
  //to try if much chanages if PXY is repressed by both Plt and ANT
  //  double pltreprpxy =pow (PltsKMPXY, pltskmPXYpwr)/(pow (PltsKMPXY, pltskmPXYpwr)+ pow(( Plts[q]+ANT[q]) ,pltskmPXYpwr));

 

#ifndef EXPLICITPXYBINDING 
  //this is the situation in which we compute what would be the CLE41-PXY complex formation to be able to induce ANT/PLT expression
  //yet without substracting this from the levels of free CLE41 and PXY
  dtPXY = tstep*speedup2*(maxPXY* auxinindpxy *((1.-PltsfacPXY)+PltsfacPXY *pltreprpxy) -decayPXY*PXY[q]);
  dtCLE41=tstep*speedup2*(CLEproduction-decayCLE41*CLE41[q]);
  double b = (PXYdiss/PXYass +PXY[q]+CLE41[q] ) ;
  double d = b*b - 4*PXY[q]*CLE41[q];
  double boundPXY = (sqrt(d)-b)/-2.;
  PXYbound[q]=boundPXY;
#else 
  //this is the "normal" situation					
  //PXY and CLE41 associate to form PXYbound, hence these molecules disappear from the free PXY and CLE41 pool
  //Similarly if PXYbound dissociates into PXY and CLE41 PXYbound decreases and free PXY and CLE41 increase
  //Finally, PXYbound degrades at the rate targetdegraded which is set to be equal to the PXY degradation rate (higher than that of CLE41)
  dtPXY = tstep*speedup2*(maxPXY* auxinindpxy *((1.-PltsfacPXY)+PltsfacPXY *pltreprpxy) -decayPXY*PXY[q] -PXYass *(PXY[q]*CLE41[q])+PXYdiss*PXYbound[q]);
  dtCLE41=tstep*speedup2*(CLEproduction-decayCLE41*CLE41[q] -PXYass *(PXY[q]*CLE41[q])+PXYdiss*PXYbound[q]);
  dtPXYbound =  tstep*speedup2*(PXYass* (PXY[q]*CLE41[q]) - PXYdiss * PXYbound[q] - targetdegraded*PXYbound[q]);
  double boundPXY = PXYbound[q]; 

  //if(t %3600 ==0)
  //printf("%f %f  %f %f \n",localaux, auxinindpxy,Plts[q]+ANT[q], pltreprpxy);

#endif

  return std::make_tuple(dtPXY, dtCLE41,dtPXYbound ,boundPXY);
	
}


void UpdateGeneExpression(int t)
{
  int q;
  int i,j;
  double localaux;
  double localarf;
  double localarf2;
  double localplts;
  double localplts2;

  int maxQxylem = 0;
  for(q=0;q<actcells;q++)
    {
      if (CellZonationState[q]== -100)
	maxQxylem +=1;
    }
  double xylemreduc = 0;
  int xylemdev= 0;
  //update gene expression levels: cell based

  bool unbrokenxylem = true;
  
  //alternative code for TDIF, PXY and TDIF-PXY updating
  for(i=0;i<n;i++)
    for(j=0;j<m;j++)
      {
	double binding;
	double unbinding;
	double prodCLE41;
	double CLEproduction;
	double degrCLE41;
	double prodPXY;
	double degrPXY;
	double degrcomplex;

	
	if(Cell[i][j]!=-1)
	  {
	    q=Cell[i][j];
	    if (CellZonationState[q]>=50)//i.e. cell is of phloem type
	      {
		if (CellZonationState[q]==100) //fully developed phloem cell
		  {//extraCLEprod defines the CLE production/influx from mature phloem cells, 0 in our simulations as we do not have developing versus mature phloem cells
		    CLEproduction = maxCLE41+globalCLEprod+extraCLEprod;
		  }
		else //developing phloem cell
		  {
		    CLEproduction= maxCLE41+globalCLEprod; // CLE production by committed but not yet fully mature phloem cells
		  } 
	      }
	    else//non phloem cells
	      {
		CLEproduction= globalCLEprod; // used if we want to ectopically ect TDIF/CLE to all tissues Typically 0 
	      }

	    prodCLE41=CLEproduction;
	    degrCLE41=decayCLE41;
	    double auxinindpxy =pow (ARF[q], auxkmPXYpwr)/(pow (ARF[q], auxkmPXYpwr)+ pow(auxkmPXY,auxkmPXYpwr));
	    double pltreprpxy =pow (PltsKMPXY, pltskmPXYpwr)/(pow (PltsKMPXY, pltskmPXYpwr)+ pow(( Plts[q]) ,pltskmPXYpwr));
	    prodPXY= maxPXY*auxinindpxy *((1.-PltsfacPXY)+PltsfacPXY *pltreprpxy);
	    degrPXY=decayPXY;
	    degrcomplex=targetdegraded;
	  }
	else
	  {
	    prodCLE41=0;
	    degrCLE41= decayCLE41;//0;//
	    prodPXY=0;
	    degrPXY=0;
	    degrcomplex=0;
	  }

	  binding= PXYass*CLE41grid[i][j]*PXYgrid[i][j];
	  unbinding= PXYdiss*boundPXYgrid[i][j];

	CLE41grid[i][j]+=tstep*speedup2*(prodCLE41-degrCLE41*CLE41grid[i][j] -binding+unbinding);
	PXYgrid[i][j]+=tstep*speedup2*(prodPXY-degrPXY*PXYgrid[i][j] -binding+unbinding);
	boundPXYgrid[i][j]+=tstep*speedup2*(binding-unbinding-degrcomplex*boundPXYgrid[i][j] );
      }


  for(q=0;q<actcells;q++)
    {
      double dtARF,dtPlts,dtPXY,dtCLE41,dtCLE44,dtWOX4,dtANT,dtHDZIP3,dtPin,dtAUX1,dtPXYbound,boundPXY;
      std::tuple<double,bool,double,int> Auxindata =  defineAuxingradient(q,maxQxylem,t,unbrokenxylem,xylemreduc,xylemdev);
      localaux =std::get<0>( Auxindata);unbrokenxylem =std::get<1>( Auxindata);
      xylemreduc=std::get<2>( Auxindata);xylemdev= std::get<3>( Auxindata);
      
      // auxdelay allows for slower than instant auxin fluctuations.
      dtARF=tstep*speedup2*((localaux-ARF[q])*auxdelay);
      localaux= ARF[q];


     
      //this is the default code when TDIF diffusion etc is done cell based
      /*
      std::tuple<double,double,double,double> PXYCLEset = updatePXYCLE(t,q,localaux);
      dtPXY =std::get<0>( PXYCLEset) ;
      dtCLE41= std::get<1>( PXYCLEset) ;
      dtPXYbound =std::get<2>( PXYCLEset) ;
      boundPXY =std::get<3>( PXYCLEset) ; 
      */
      //alternative code when TDIF diffusion, PXY and TDIF-PXY binding are grid based see above


      //to be able to control cell level gene expression we need to convert grid based boundPXY to cell level boundPXY
      double sum=0;
      for(i=CellMinI[q];i<=CellMaxI[q];i++)
	for(j=CellMinJ[q];j<=CellMaxJ[q];j++)
	  sum+=boundPXYgrid[i][j];
      boundPXY=sum*InvCellSizes[q];
      PXYbound[q]=boundPXY;
      //not needed but just to also have TDIF and PXY on cell level
      sum=0;
      for(i=CellMinI[q];i<=CellMaxI[q];i++)
	for(j=CellMinJ[q];j<=CellMaxJ[q];j++)
	  sum+=CLE41grid[i][j];
      CLE41[q]=sum*InvCellSizes[q];
      sum=0;
      for(i=CellMinI[q];i<=CellMaxI[q];i++)
	for(j=CellMinJ[q];j<=CellMaxJ[q];j++)
	  sum+=PXYgrid[i][j];
      PXY[q]=sum*InvCellSizes[q];
	 


      
      dtHDZIP3= tstep*speedup2*(maxHDZIP3* ((1.0-facHDZIP3)+facHDZIP3 * pow (localaux, auxkmhdzippwr)/(pow (localaux, auxkmhdzippwr)+ pow(AuxKMHDZIP,auxkmhdzippwr)))-decayHDZIP3*HDZIP3[q]);    
      
      //repressive effect of HDZIP3 on ANT expression
      double HDZIPANTeffect= ((1.-ANTHDZIPfac)+ANTHDZIPfac*pow (HDZIPKMANT, HDZIPKMANTpwr)/(pow (HDZIPKMANT, HDZIPKMANTpwr)+ pow(HDZIP3[q],HDZIPKMANTpwr)));

      //inductive effect of auxin on ANT expression
      double AuxinANTeffect = (ANTAuxfac* pow (localaux, AuxinkmANTpwr)/(pow (localaux, AuxinkmANTpwr)+ pow(AuxinKMANT,AuxinkmANTpwr)));

      //inductive effect of PXY-CLE on ANT expression
      double PXYCLEANTeffect = (ANTPXYfac* pow (boundPXY, PXYkmANTpwr)/(pow (boundPXY, PXYkmANTpwr)+ pow(PXYKMANT,PXYkmANTpwr)) ) ;


#ifdef HDZIPAUXINEFFONLY //only auxin part of ANT induction repressed by HDZIPIII.
      //used for the strong sequestration scenario
      AuxinANTeffect *= HDZIPANTeffect;
      dtANT  =  tstep*speedup2*(maxANT * ( (1.0-ANTPXYfac-ANTAuxfac)+PXYCLEANTeffect+AuxinANTeffect )  -decayANT  * ANT[q] );
#endif
#ifdef HDZIPFULLEFF //HDZIP affects both auxin and PXYCLE component of ANT induction. 
      // Used in weak sequestration scenario and single cell sweeps
      dtANT  =  tstep*speedup2*(maxANT * HDZIPANTeffect* ( (1.0-ANTPXYfac-ANTAuxfac)+PXYCLEANTeffect+AuxinANTeffect )  -decayANT  * ANT[q] );
#else
      dtANT  =  tstep*speedup2*(maxANT * ( (1.0-ANTPXYfac-ANTAuxfac)+PXYCLEANTeffect+AuxinANTeffect )  -decayANT  * ANT[q] );
#endif
      

      dtPlts =  tstep*speedup2*(maxPlts* ((1.0-pltsfac)+pltsfac*(pow (boundPXY, PXYkmPLTpwr)/(pow (boundPXY, PXYkmPLTpwr)+ pow(PXYKMPLTS,PXYkmPLTpwr)))) -decayPlts * Plts[q]);
      
      
      if (CellZonationState[q]!=-100)
	{
	  ARF[q] += dtARF; //ARF is where we store our current auxin values
	  ANT[q]+=dtANT;
	  Plts[q]+=dtPlts;
	  //this is the default code when TDIF diffusion etc is done cell based
	  /*PXY[q] += dtPXY; 
	    PXYbound[q] +=dtPXYbound;
	    CLE41[q]+= dtCLE41;*/
	  //for alternative code see above
	  HDZIP3[q]+= dtHDZIP3;
	}
      else  
	{// cells with state -100 are xylem vessel cells and thus have no content
	  ARF[q] = 0;
	  ANT[q]= 0;
	  Plts[q]= 0;
	  PXY[q] = 0;
	  PXYbound[q] = 0;	  
	  CLE41[q]= 0;
	  HDZIP3[q]= 0;
	}
    }

  if(actcells>1)//only transport if multiple cells
    {
      double pltsdiffusion =tstep*speedup2*(pltsdiff);
      //incorporate multiplication with 23 to obtain similar results 
      //as in default code
      double CLE41diffusion =tstep*speedup2*(CLE41diff);// *23;
      CellularDiffusion(Plts,pltsdiffusion/(xstep*xstep),pltsdiffusion/(xstep*xstep));
      CellularDiffusion(ANT,pltsdiffusion/(xstep*xstep),pltsdiffusion/(xstep*xstep));
      //this is the default code when TDIF diffusion etc is done cell based
      /*
      CellularDiffusion(CLE41,CLE41diffusion/(xstep*xstep),CLE41diffusion/(xstep*xstep));
      */
      //alternative code for when TDIF diffusion is done grid based       
      for(i=0;i<n;i++)
	for(j=0;j<m;j++)
	  {
	    //exceptions, corners & edgjes
	    if(i==0 && j==0)//left
	      CLE41grid2[i][j]=CLE41grid[i][j]+( CLE41diffusion/(xstep*xstep))*(CLE41grid[i+1][j]+CLE41grid[i][j+1]-2*CLE41grid[i][j]);
	    else if(i==0 && j==m-1)
	      CLE41grid2[i][j]=CLE41grid[i][j]+( CLE41diffusion/(xstep*xstep))*(CLE41grid[i+1][j]+CLE41grid[i][j-1]-2*CLE41grid[i][j]);
	    else if(i==n-1 && j==0)
	      CLE41grid2[i][j]=CLE41grid[i][j]+( CLE41diffusion/(xstep*xstep))*(CLE41grid[i-1][j]+CLE41grid[i][j+1]-2*CLE41grid[i][j]);
	    else if(i==n-1 && j==m-1)
	      CLE41grid2[i][j]=CLE41grid[i][j]+( CLE41diffusion/(xstep*xstep))*(CLE41grid[i-1][j]+CLE41grid[i][j-1]-2*CLE41grid[i][j]); 
	    else if(i==0)
	      CLE41grid2[i][j]=CLE41grid[i][j]+( CLE41diffusion/(xstep*xstep))*(CLE41grid[i+1][j]+CLE41grid[i][j-1]+CLE41grid[i][j+1]-3*CLE41grid[i][j]);
	    else if(i==n-1)
	      CLE41grid2[i][j]=CLE41grid[i][j]+( CLE41diffusion/(xstep*xstep))*(CLE41grid[i-1][j]+CLE41grid[i][j-1]+CLE41grid[i][j+1]-3*CLE41grid[i][j]);
	    else if(j==0)
	      CLE41grid2[i][j]=CLE41grid[i][j]+( CLE41diffusion/(xstep*xstep))*(CLE41grid[i-1][j]+CLE41grid[i+1][j]+CLE41grid[i][j+1]-3*CLE41grid[i][j]); 
	    else if(j==m-1)
	      CLE41grid2[i][j]=CLE41grid[i][j]+( CLE41diffusion/(xstep*xstep))*(CLE41grid[i-1][j]+CLE41grid[i+1][j]+CLE41grid[i][j-1]+CLE41grid[i][j+1]-3*CLE41grid[i][j]); 
	    else
	      {
		CLE41grid2[i][j]=CLE41grid[i][j]+( CLE41diffusion/(xstep*xstep))*(CLE41grid[i-1][j]+CLE41grid[i+1][j]+CLE41grid[i][j-1]+CLE41grid[i][j+1]-4*CLE41grid[i][j]);
	      }

	  }
      
       for(i=0;i<n;i++)
	for(j=0;j<m;j++)
	  {
	    CLE41grid[i][j]=CLE41grid2[i][j];
	  }
      
    }
}



