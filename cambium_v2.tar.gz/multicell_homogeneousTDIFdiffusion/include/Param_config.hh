#ifndef ConfigHeader
#define ConfigHeader

using namespace std;

#include "Basic_params.hh"
#include "Plant_layout.hh"
#include <cstring>

//Below the #define XXX statements allow you to switch between
//different types of conditions to be simulated
//To "activate" a define statement uncomment it (no // in front)
//to "inactivate a define statement comment it (// in front)



//Putting this factor to >1 one can demonstrate that higher diffusion constants
//for TDIF are possible if at the same time higher turnover rates for TDIF,
//PXY and TDIF-PXY complex are used
//Note that currently this scaling>1 is only implemented for STRONGSEQUESTRATION
static  double scaling=1;//



//only on of the three below should be switched on
//#define INITIALMULTICELL
// #define STRONGANTREPRESSION //note that this involves not defining  EXPLICITPXYBINDING see below
#define STRONGSEQUESTRATION //note that this requires  HDZIPAUXINEFFONLY instead of HDZIPFULLEFF see below


#ifdef STRONGSEQUESTRATION
#define EXPLICITPXYBINDING //if this is not defined, we calculate PXY-CLE as 
// a steady state of the current PXY and CLE levels, and avoid the 
// sequestering effect. This is done under the strong HDZIPIII scenario to
//  model a non-sequester example.
#endif


#ifndef STRONGSEQUESTRATION
#define HDZIPFULLEFF
#else
#define HDZIPAUXINEFFONLY //this is defined under the strong sequestering example to
//restrict the HDZIPIII repression to small faction of ANT induction directly caused by auxin.
#endif


const double auxmax_min = 100;
extern double auxmax; // auxmax (the maximum auxin level in the xylem) is set by auxmax_min
const double globalCLEprod_min = 0.00;// 4*0.004;// 0.00;
const double extraCLEprod = 0.00;
extern double globalCLEprod;


#define LOWERAUXUNDIF 	// if this is turned on the cells xylemward of the xylem organiser have less auxin than the auxin maximum.
			// if undefined all these cells will have the maximum auxin level and auxin drops after the xylem organiser.
#define PHLOEMAUXINGRAD // if this is turned on the phloem has explicit auxin levels depending on the exponential gradient. 




//delays changes in the auxin shifts to create a more gradual transition when a new xylem organiser is formed and the gradient is repositioned.
//only has an effect in growing tissues, not so relevant in this code.
const double auxdelay = 0.01;


//Gene expression parameters

const double maxPlts=0.002;
const double decayPlts=0.00002;
const double pltsfac=1.;
const double pltsdiff = 0.00002/8.0 ;//PLT plasmodesmatal flux rate 
const double PXYKMPLTS = 40;
const double PXYkmPLTpwr = 2;


//PXY parameters
const double maxPXY= 0.12*scaling ; // 0.12 is 100% PXY; 0.06 is 50% PXY; 0.04 is 33.33% PXY; 0.03 is 25% PXY.
const double decayPXY = 0.0012 *scaling;
const double auxkmPXY = 25;
const double auxkmPXYpwr= 2;
const double PltsKMPXY = 50;
const double pltskmPXYpwr = 2;
const double PltsfacPXY = 0.3;
const double targetdegraded = 0.0012*scaling ; // this should be equal to the PXY degradation rate.


#ifdef INITIALMULTICELL
const double maxCLE41=0.04;
#endif
#ifdef STRONGANTREPRESSION 
const double maxCLE41=0.03;
#endif
#ifdef STRONGSEQUESTRATION
const double maxCLE41=0.13*scaling ;
#endif
#ifdef INITIALMULTICELL
const double PXYdiss = 0.1;
#endif
#ifdef STRONGSEQUESTRATION
const double PXYdiss = 0.02;
#endif
#ifdef STRONGANTREPRESSION
const double PXYdiss = 0.02;
#endif
const double decayCLE41 = 0.0002*scaling;
const double CLE41diff=(0.015/8.0 )*scaling ;//basic diffusion rate for CLE
const double PXYass = 0.02;



//ANT PARAMETERS
const double maxANT= 0.002;
const double decayANT = 0.00002;
const double ANTPXYfac = 0.8; // ANTPXYfac and ANTAuxfac together may not exceed 1. If they are below 1 the remaining value represents 'always on' induction' 
const double PXYKMANT = 20;
const double PXYkmANTpwr = 2;
const double ANTAuxfac = 0.2; // ANTPXYfac and ANTAuxfac together may not exceed 1. If they are below 1 the remaining value represents 'always on' induction'
const double AuxinKMANT = 20;
const double AuxinkmANTpwr = 2;
const double ANTHDZIPfac = 1;
const double HDZIPKMANT = 45;
const double HDZIPKMANTpwr = 2;

//HDZIP parameters
const double maxHDZIP3 = 0.02;
const double decayHDZIP3 = 0.0002;
const double facHDZIP3 = 1.0;
const  double AuxKMHDZIP = 55;
const double auxkmhdzippwr = 4;


#endif






