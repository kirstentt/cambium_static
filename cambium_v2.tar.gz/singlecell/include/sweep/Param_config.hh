#ifndef ConfigHeader
#define ConfigHeader

using namespace std;

#include "Basic_params.hh"
#include "Plant_layout.hh"
#include <cstring>

//Below the #define XXX statements allow you to switch between
//different types of conditions to be simulated
//To "activate" a define statement uncomment it (no // in front)
//to "inactivate a define statement comment it (// in front)


//#define RESTART //to restart from a previously stored condition 
                  //(default is starting the simulation from scratch)


#define PLASMODESMATAOPEN //to allow PLT to move between cells (gradient extension & smoothening)


#define GENEEXPRESSION //dynamic updating of all gene expression levels



#define PARAMSWEEP
#define SIMPLEPLOT //this suppresses making PNG files, which would become massive for a 9dimensional parameter sweep


const double auxmax_min = 10.;
extern double auxmax;
const double globalCLEprod_min = 0.002*100;
const double extraCLEprod = 0.00;
extern double globalCLEprod;
#define MULTIRUN //turn this on if you want to do a series of runs instead of a singular one. Will create nested directories for different runs
#ifdef MULTIRUN
const double auxmax_stepsize = 10.;
const double auxmax_maxsize = 111.;
const double globalCLEprod_stepsize= 0.002*100;//0.02 wt
const double globalCLEprod_maxsize = 0.03002*100;
#endif

#define LOWERAUXUNDIF


//PLT plasmodesmatal flux rate 
const double pdflux=0.04/(double)xstep;


//auxin parameters:
const double auxdelay = 0.01;


//Gene expression parameters

const double PXYKMPLTSmin = 40;//first parameter to switch 20- 40 (5 runs)
const double auxkmPXYmin = 30; // second parameter to switch 15-35 (5 runs)
const double PltsKMPXYmin = 50;// third parameter to switch 30-60 (4 runs)



const double maxPlts=0.02;//0.025 with diffusion to other cells.
const double decayPlts=0.0002;
const double pltsfac=1.;
const double pltsdiff = 0.00002;
extern double PXYKMPLTS; //is being varied for sweep //1 //corresponds to K_P,X
const double PXYKMPLTSstep = 0.5;//step size for sweep //WHY IS THIS NOT 5
// defined up for split sweep const double PXYKMPLTSmin = 20; //first parameter to switch 20- 40 (5 runs) 
const double PXYKMPLTSmax = 60;//max value sweep //WHY IS THIS NOT 50
const double PXYkmPLTpwr = 2;
#define CHECKPHLOEMPXYCLE



const double maxPXY= 0.12;
const double decayPXY = 0.0012;

extern double auxkmPXY; //is being varied in sweep //2 //corresponds to K_X,a/K_a,X             
const double auxkmPXYstep = 0.5;//step size for sweep   //WHY IS THIS NOT 5
// defined for split sweep const double auxkmPXYmin = 20; // second parameter to switch 15-35 (5 runs)
const double auxkmPXYmax = 35;//max value sweep
const double auxkmPXYpwr= 2;

extern double PltsKMPXY;//is being varied in sweep //3 //corresponds to K_P,C/K_C,P
const double PltsKMPXYstep = 0.5;//step size for sweep  //WHY IS THIS NOT 5
// defined for split sweep  const double PltsKMPXYmin = 30; //check third parameter to switch between 30 and 60
const double PltsKMPXYmax = 60;//max value sweep //WHY NOT BETWEEN 20 AND 40
const double pltskmPXYpwr = 2;

extern double PltsfacPXY;//is being varied in sweep //4 //corresponds to f_P,X
const double PltsfacPXYstep = 0.5;//step size for sweep (so not used, as immediately above max)
const double PltsfacPXYmin = 0.5;//min value sweep //WHY IS THIS NOT AT 0.3
const double PltsfacPXYmax = 0.6;//max value sweep


#define EXPLICITSEQUESTER
#ifdef EXPLICITSEQUESTER
const double targetdegraded = 0.0012;
#endif 

//#define PXYFREED
//#define CLEFREED

const double maxCLE41= 0.0;
const double decayCLE41 = 0.0002*100; //*100 because in sweeps there is time dependent interaction
const double CLE41diff= 0.02;
const double PXYass = 0.02;
const double PXYdiss = 0.1;


//ANT PARAMETERS
const double maxANT= 0.02;//0.025 with diffusion to other cells.
const double decayANT = 0.0002;
const double ANTPXYfac = 0.8; // these two together may not exceed 1.//IN SUPPLEMENT THIS IS SUPPOSEDLY SWEEPED HERE NOT
extern double PXYKMANT;//is being varied in sweep //5 //corresponds to K_C,A 
const double PXYKMANTstep = 2;//step size for sweep //WHY IS THIS NOT 5
const double PXYKMANTmin = 30; //min value sweep //WHY NOT 15
const double PXYKMANTmax = 40;//max value sweep//WHY NOT 35
const double PXYkmANTpwr = 2;
const double ANTAuxfac = 0.2; // these two together may not exceed 1.//IN SUPPLEMENT THIS IS SUPPOSEDLY SWEEPED HERE NOT
extern double AuxinKMANT;//is being varied in sweep //6 //corresponds to K_a,A
const double AuxinKMANTstep = 5;//step size for sweep
const double AuxinKMANTmin = 15;//min value sweep
const double AuxinKMANTmax = 40;//max value sweep //WHY IS THIS NOT 35
const double AuxinkmANTpwr = 2;
extern double ANTHDZIPfac;//is being varied in sweep //7 //corresponds to r_H,a= r_H,C 
const double ANTHDZIPfacstep = 4;//step size for sweep //WHY IS THIS NOT 0.1
const double ANTHDZIPfacmin = 0.4;//min value sweep
const double ANTHDZIPfacmax = 1.0;//max value sweep
extern double HDZIPKMANT;//is being varied in sweep //8 //corresponds to K_H,A
const double HDZIPKMANTstep = 4;//step size for sweep //WHY IS THIS NOT 5
const double HDZIPKMANTmin = 30;//min value sweep
const double HDZIPKMANTmax = 50;//max value sweep
const double HDZIPKMANTpwr = 2;

//HDZIP parameters
const double maxHDZIP3 = 0.03;
const double decayHDZIP3 = 0.0003;
const double facHDZIP3 = 1.0;
extern double AuxKMHDZIP; //is being varied in sweep //9 //corresponds to K_a,H
const double AuxKMHDZIPstep = 4;//step size sweep //WHY IS THIS NOT 10
const double AuxKMHDZIPmin = 30;//min value sweep
const double AuxKMHDZIPmax = 70;//max value sweep
const double auxkmhdzippwr = 4;
#define HDZIPNOPLTANTAGONIZE //no PLT repression by HDZIP
const double PLTHDZIPfac = 0.4;
const double HDZIPKMPLT = 40;
const double HDZIPKMPLTpwr = 2;







#endif






