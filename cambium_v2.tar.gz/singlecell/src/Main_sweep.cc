/*

DigitalRoot simulates the regulation of root growth and developmental 
zonation by the phytohormone auxin and the PLETHORA transcription factors  
in a simplified, two dimensional model of the Arabidopsis root.

Copyright 2012-2014, Kirsten ten Tusscher


DigitalRoot is distributed under the terms of the GNU General Public 
License.


DigitalRoot is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

DigitalRoot is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with DigitalRoot.  If not, see <http://www.gnu.org/licenses/>.

*/
#include "Param_config.hh"
#include "Basic_params.hh"
#include "Functions.hh"
#include "Arrays.hh"
#include "Plant_layout.hh"



double  sweepresults[11][6][3];
long sweepcounter;

double sweepHDZIP3[11][6];
double sweepPLTANT[11][6];
double sweepPXY[11][6];
double sweepCLEPXY[11][6];
double sweepPLT[11][6];
double sweepANT[11][6];

char dirname[2000];
char maindirname[2000];
int actcells;
//sweeping parameters
double auxmax;
double globalCLEprod;


double PXYKMPLTS;
double auxkmPXY;
double PltsKMPXY;
double PltsfacPXY;
double PXYKMANT;
double AuxinKMANT;
double ANTHDZIPfac;
double HDZIPKMANT;
double AuxKMHDZIP;
double ANTAuxfac;
double ANTPXYfac;


//Grid based properties
int Tc[n][m];
int **Tmt;



//Cell based properties
int Cell[n][m];
int CellSizes[totcells];
double InvCellSizes[totcells];
int CellMinI[totcells];
int CellMinJ[totcells];
int CellMaxI[totcells];
int CellMaxJ[totcells];
int CellWidth[totcells];
int CellHeight[totcells];
int CellZonationState[totcells];
double ARF[totcells];
double Plts[totcells];
double HDZIP3[totcells];
double ANT[totcells];
double CLE41[totcells];
double PXY[totcells];
double PXYbound[totcells];

static int colourmap[255][3]=
{{0, 0, 0},
{0, 0, 7},
{0, 0, 9},
{0, 0, 12},
{0, 0, 14},
{0, 0, 17},
{0, 0, 19},
{0, 0, 22},
{0, 0, 24},
{0, 0, 27},
{0, 0, 29},
{0, 0, 32},
{0, 0, 34},
{0, 0, 37},
{0, 0, 39},
{0, 0, 42},
{0, 0, 44},
{0, 0, 47},
{0, 0, 49},
{0, 0, 52},
{0, 0, 54},
{0, 0, 57},
{0, 0, 59},
{0, 0, 62},
{0, 0, 64},
{0, 0, 67},
{0, 0, 69},
{0, 0, 72},
{0, 0, 74},
{0, 0, 77},
{0, 0, 79},
{0, 0, 82},
{0, 0, 84},
{0, 0, 87},
{0, 0, 89},
{0, 0, 92},
{0, 0, 94},
{0, 0, 97},
{0, 0, 99},
{0, 0, 102},
{0, 0, 104},
{0, 0, 107},
{0, 0, 109},
{0, 0, 112},
{0, 0, 114},
{0, 0, 117},
{0, 0, 119},
{0, 0, 122},
{0, 0, 124},
{0, 0, 127},
{0, 0, 129},
{3, 0, 127},
{7, 0, 126},
{10, 0, 124},
{13, 0, 122},
{16, 0, 121},
{19, 0, 119},
{22, 0, 117},
{26, 0, 116},
{29, 0, 114},
{32, 0, 112},
{35, 0, 111},
{38, 0, 109},
{41, 0, 107},
{44, 0, 106},
{48, 0, 104},
{51, 0, 102},
{54, 0, 101},
{57, 0, 99},
{60, 0, 97},
{63, 0, 96},
{66, 0, 94},
{69, 0, 93},
{72, 0, 92},
{75, 0, 90},
{77, 0, 89},
{80, 0, 88},
{83, 0, 86},
{87, 0, 85},
{90, 0, 84},
{93, 0, 82},
{96, 0, 81},
{98, 0, 80},
{101, 0, 78},
{104, 0, 77},
{107, 0, 76},
{110, 0, 74},
{113, 0, 73},
{116, 0, 72},
{119, 0, 70},
{120, 0, 69},
{123, 0, 68},
{126, 0, 66},
{127, 0, 64},
{129, 0, 63},
{132, 0, 62},
{135, 0, 60},
{137, 0, 58},
{140, 0, 56},
{143, 0, 54},
{146, 0, 52},
{149, 0, 51},
{151, 0, 50},
{154, 0, 48},
{157, 0, 47},
{160, 0, 46},
{163, 0, 44},
{165, 0, 43},
{168, 0, 42},
{171, 0, 40},
{174, 0, 39},
{176, 0, 38},
{179, 0, 36},
{182, 0, 35},
{185, 0, 34},
{188, 0, 32},
{190, 0, 31},
{193, 0, 30},
{196, 0, 28},
{199, 0, 27},
{202, 0, 26},
{204, 0, 24},
{207, 0, 23},
{210, 0, 22},
{213, 0, 20},
{215, 0, 19},
{218, 0, 18},
{221, 0, 16},
{224, 0, 15},
{227, 0, 14},
{229, 0, 12},
{232, 0, 11},
{235, 0, 10},
{238, 0, 8},
{241, 0, 7},
{243, 0, 6},
{246, 0, 4},
{249, 0, 3},
{252, 0, 2},
{255, 0, 0},
{255, 0, 0},
{255, 3, 0},
{255, 6, 0},
{255, 8, 0},
{255, 11, 0},
{255, 13, 0},
{255, 16, 0},
{255, 18, 0},
{255, 21, 0},
{255, 24, 0},
{255, 26, 0},
{255, 29, 0},
{255, 31, 0},
{255, 34, 0},
{255, 36, 0},
{255, 39, 0},
{255, 41, 0},
{255, 43, 0},
{255, 47, 0},
{255, 49, 0},
{255, 52, 0},
{255, 55, 0},
{255, 58, 0},
{255, 61, 0},
{255, 64, 0},
{255, 67, 0},
{255, 70, 0},
{255, 72, 0},
{255, 75, 0},
{255, 77, 0},
{255, 80, 0},
{255, 83, 0},
{255, 85, 0},
{255, 88, 0},
{255, 90, 0},
{255, 93, 0},
{255, 96, 0},
{255, 98, 0},
{255, 101, 0},
{255, 104, 0},
{255, 106, 0},
{255, 109, 0},
{255, 111, 0},
{255, 114, 0},
{255, 117, 0},
{255, 119, 0},
{255, 122, 0},
{255, 124, 0},
{255, 127, 0},
{255, 130, 0},
{255, 132, 0},
{255, 135, 0},
{255, 137, 0},
{255, 140, 0},
{255, 142, 0},
{255, 145, 0},
{255, 148, 0},
{255, 150, 0},
{255, 153, 0},
{255, 155, 0},
{255, 158, 0},
{255, 160, 0},
{255, 163, 0},
{255, 166, 0},
{255, 168, 0},
{255, 171, 0},
{255, 173, 0},
{255, 176, 0},
{255, 178, 0},
{255, 180, 0},
{255, 183, 0},
{255, 186, 0},
{255, 188, 0},
{255, 191, 0},
{255, 193, 0},
{255, 196, 0},
{255, 198, 0},
{255, 201, 0},
{255, 204, 0},
{255, 207, 0},
{255, 209, 0},
{255, 212, 0},
{255, 215, 0},
{255, 218, 0},
{255, 221, 0},
{255, 223, 0},
{255, 226, 0},
{255, 229, 0},
{255, 231, 0},
{255, 234, 0},
{255, 236, 0},
{255, 239, 0},
{255, 242, 0},
{255, 245, 0},
{255, 248, 0},
{255, 251, 0},
{255, 255, 0},
{255, 255, 14},
{255, 255, 28},
{255, 255, 43},
{255, 255, 57},
{255, 255, 71},
{255, 255, 85},
{255, 255, 99},
{255, 255, 113},
{255, 255, 128},
{255, 255, 142},
{255, 255, 156},
{255, 255, 170},
{255, 255, 184},
{255, 255, 199},
{255, 255, 213},
{255, 255, 227},
{255, 255, 241},
{255, 255, 255}
};




void MakeArrays()
{

  int i,j,k;            	

  for(i=0;i<n;i++)
    for(j=0;j<m;j++)
      Tc[i][j]=0;
  //Tmt
  if (( Tmt = new int*[n]) == NULL )
    { printf("error in allocating Tmt array\n"); exit(1);}
  for ( i = 0; i < n; i++ )
    {
      if (( Tmt[i] = new int[m]) == NULL )
	{ printf("error in allocating Tmt array\n"); exit(1);}
    }
  for(i=0;i<n;i++)
    for(j=0;j<m;j++)
      Tmt[i][j]=0;
}

void FreeArrays()
{
  int i,j;

  for(i = 0; i < n; i++)
    delete[] Tmt[i];
  delete[] Tmt;
}
  

void Start(int argc, char **argv)
{
  if(argc<2)
    {
      printf("usage: exc dirname\n");
      exit(1);
    }
  else
    {
      strcpy(dirname,argv[1]);
      strcpy(maindirname,argv[1]);
    }
}

void MakePNGFileSWEEP(char *dirname, double C[11][6][3])
{
  int i,j;
  int ii,jj;
  int iii,jjj;

  FILE *PNGFileP;
  png_structp png_ptr;
  png_infop info_ptr;
  png_bytep row_pointer;
  char fname[500];
  const int WW=6*25;// ;//TDIF
  const int LL=11 *25;//auxin
  unsigned char RGBdata[LL*WW*3];
  double temp;
  int q;
  
  sprintf(fname,"%s/SWEEPresults.png",dirname);   
  
  for(i=0;i<11;i++)
    for(j=0;j<6 ;j++)
      {
	for(ii=0;ii<25;ii++)
	  for(jj=0;jj<25;jj++)
	    {
	      iii=25*i+ii;
	      jjj=25*j+jj;

	      double g;
	      g=(C[i][j][0]-0.333)*(C[i][j][0]-0.333)+(C[i][j][1]-0.333)*(C[i][j][1]-0.333)+(C[i][j][2]-0.333)*(C[i][j][2]-0.333);
	      g=sqrt(g);
	      RGBdata[jjj*LL*3+iii*3+0]=max(192*C[i][j][0], 254*(1-g));
	      RGBdata[jjj*LL*3+iii*3+1]=max(192*C[i][j][0],254*C[i][j][1]);
	      RGBdata[jjj*LL*3+iii*3+2]=max(192*C[i][j][0],254*C[i][j][2]);
	    }
      }
 
	   
  PNGFileP = fopen(fname, "wb");
  png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING,(png_voidp) NULL,
                    (png_error_ptr) NULL,
                    (png_error_ptr) NULL );
  if(!png_ptr){
    printf("out of memory\n");
    exit(1);
  }
  info_ptr = png_create_info_struct ( png_ptr );
  if(!info_ptr){
    png_destroy_write_struct(&png_ptr, NULL);
    printf("out of memory\n");
    exit(1);
  }
  png_init_io ( png_ptr, PNGFileP );
  png_set_IHDR(png_ptr, info_ptr,LL,WW,
           8, PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE,
           PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
  png_write_info ( png_ptr, info_ptr );
  /*write out image, one row at a time*/
  int row;
  for(row = WW-1; row >= 0; row--){
    row_pointer = ( RGBdata + LL * row * 3 );
    png_write_rows ( png_ptr, &row_pointer, 1 );
  }
  png_write_end ( png_ptr, info_ptr );
  fflush ( PNGFileP );
  png_destroy_write_struct ( &png_ptr,&info_ptr);
  fclose(PNGFileP);
}  

void MakePNGFileGenes(char *dirname, double C[11][6],int flag)
{
  int i,j;
  int ii,jj;
  int iii,jjj;
  
  FILE *PNGFileP;
  png_structp png_ptr;
  png_infop info_ptr;
  png_bytep row_pointer;
  char fname[500];
  const int WW=6*25;//TDIF   
  const int LL=11*25;//auxin 
  unsigned char RGBdata[LL*WW*3];
  int colour;
  int CColour[LL][WW];
  double temp;
  int q;
  
  if(flag==1)
    sprintf(fname,"%s/SWEEPresultsHDZIP3.png",dirname);   
  else if(flag==2)
    sprintf(fname,"%s/SWEEPresultsPltsANT.png",dirname);
  else if(flag==3)
    sprintf(fname,"%s/SWEEPresultsPXY.png",dirname); 
  else if(flag==4)
    sprintf(fname,"%s/SWEEPresultsCLEPXY.png",dirname); 
  else if(flag==5)
    sprintf(fname,"%s/SWEEPresultsPlts.png",dirname);
  else if(flag==6)
   sprintf(fname,"%s/SWEEPresultsANT.png",dirname);

  printf("hello the flag is %i\n",flag);

  
  for(i=0;i<11;i++)
    for(j=0;j<6 ;j++)
      {
	for(ii=0;ii<25;ii++)
	  for(jj=0;jj<25;jj++)
	    {
	      iii=25*i+ii;
	      jjj=25*j+jj;

	      if(flag==1)
		colour=(int)(15+(60)*(C[i][j]/100.));
	      else if(flag!=2)
		colour=(int)(35+(254-35)*(C[i][j]/100.));
	      else
		colour=(int)(35+(254-35)*(C[i][j]/150.));
	      if(colour>254)
		colour=254;

	      RGBdata[jjj*LL*3+iii*3+0]=colourmap[colour][0];
	      RGBdata[jjj*LL*3+iii*3+1]=colourmap[colour][1];;
	      RGBdata[jjj*LL*3+iii*3+2]=colourmap[colour][2];
	    }
      }
 
  /*
  for(i=0;i<11;i++)
    for(j=0;j<6;j++)
      {
	ii=i ;
	jj=j ;

	if(flag==1)
	  colour=(int)(15+(60)*(C[i][j]/100.));
	else if(flag!=2)
	  colour=(int)(35+(254-35)*(C[i][j]/100.));
	else
	  colour=(int)(35+(254-35)*(C[i][j]/150.));
	if(colour>254)
	  colour=254;
	
	RGBdata[jj*LL*3+ii*3+0]=colourmap[colour][0];             
	RGBdata[jj*LL*3+ii*3+1]=colourmap[colour][1];             
	RGBdata[jj*LL*3+ii*3+2]=colourmap[colour][2];  
      }
  */
	   
  PNGFileP = fopen(fname, "wb");
  png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING,(png_voidp) NULL,
                    (png_error_ptr) NULL,
                    (png_error_ptr) NULL );
  if(!png_ptr){
    printf("out of memory\n");
    exit(1);
  }
  info_ptr = png_create_info_struct ( png_ptr );
  if(!info_ptr){
    png_destroy_write_struct(&png_ptr, NULL);
    printf("out of memory\n");
    exit(1);
  }
  png_init_io ( png_ptr, PNGFileP );
  png_set_IHDR(png_ptr, info_ptr,LL,WW,
           8, PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE,
           PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
  png_write_info ( png_ptr, info_ptr );
  /*write out image, one row at a time*/
  int row;
  for(row = WW-1; row >= 0; row--){
    row_pointer = ( RGBdata + LL * row * 3 );
    png_write_rows ( png_ptr, &row_pointer, 1 );
  }
  png_write_end ( png_ptr, info_ptr );
  fflush ( PNGFileP );
  png_destroy_write_struct ( &png_ptr,&info_ptr);
  fclose(PNGFileP);
}  




int single_run(int argc)
{
  double dummypict[n][m];
  int time;
  int i,j,q,k;
  int starttime;

  SetUpMembraneTypes();
#ifndef RESTART
  starttime=0;
  InitPlant();
#else
  starttime=givenstart;
  InitPlantFromFile(starttime);
  starttime=(int)(starttime/tstep);
#endif

    
  for(time=starttime;time<=maxnrsteps;time++)
    {
	  

      if(time%speedup2==0)
	{
	  UpdateGeneExpression((int)(time*tstep));
	}
      

#ifndef SIMPLEPLOT
      if((int)(time*tstep)>0 && (int)(time*tstep)%50000==0)
	WritePlantToFile((int)(time*tstep));
      
      if(time%tsave==0)
	{
	  
	  for(q=0;q<actcells;q++)
	    {
	      SaveTemp((int)(time*tstep),(int)(0.5*(CellMinI[q]+CellMaxI[q])),(int)(0.5*(CellMinJ[q]+CellMaxJ[q])));
	    }
	  
	  //for png pictures we need double values
	  //dummyarray is uded tp go from int to double
	  for(i=0;i<n;i++)
	    for(j=0;j<m;j++)
	      dummypict[i][j]=Tc[i][j];
	  MakePNGFile(dirname,dummypict,(int)(time*tstep),0);

	  
	  //for png we also need values at grid level instead of cell level
	  //here we use a function to project cell level to grid level values
	  //before calling the MakePNGFile function within this function
	  prepare_Int_PNG(CellZonationState,9,(int)(time*tstep),dirname);
	  prepare_PNG(PXY,10,(int)(time*tstep),dirname);
	  prepare_PNG(PXYbound,15,(int)(time*tstep),dirname);
	  prepare_PNG(CLE41,11,(int)(time*tstep),dirname);
	  prepare_PNG(ANT,12,(int)(time*tstep),dirname);
	  prepare_PNG(HDZIP3,13,(int)(time*tstep),dirname);
	  prepare_PNG(ARF,3,(int)(time*tstep),dirname);
	  prepare_PNG(Plts,4,(int)(time*tstep),dirname);
	  prepare_Int_PNG(CellZonationState,14,(int)(time*tstep),dirname);


	  //to make a picture combining the above separate pictures
	  make_combined_figure(dirname,(int)(time*tstep));


	  Trackcontentfirst(time*tstep);
	  Trackcontentsecond(time*tstep);
	 
	}
#else
      if(time%tsave==0 && time>1000)
	{ 
	  // Trackcontentfirstsweep(time*tstep);
	  //Trackcontentsecondsweep(time*tstep); //simplified output for sweep //WHERE IS THIS FUNCTION?
	}
#endif
    }  

  return 0;
}


//vary auxin and TDIF values
int multimain(int argc, char **argv)
{

 char s[9000];

 cout << "auxmaxes min" <<auxmax_min << " max "<< auxmax_maxsize << " step " <<auxmax_stepsize<<std::endl;

 std::string basedirname = dirname;
 for(auxmax = auxmax_min;auxmax<auxmax_maxsize;auxmax+=auxmax_stepsize)
   {
     for(globalCLEprod = globalCLEprod_min;globalCLEprod < globalCLEprod_maxsize; globalCLEprod+=globalCLEprod_stepsize)
       {
	 char s[3000];
	 char auxname[3000];
	 sprintf(auxname,"%.1f",auxmax);
	 char CLEname[3000];
	 sprintf(CLEname,"%.4f",globalCLEprod);
	 std::string newdirname = std::string(basedirname) +std::string("//auxinmax_")+ std::string(auxname)+ std::string("CLEprod_")+std::string(CLEname);
	 cout << "newdirname " << newdirname <<std::endl;
	 strcpy(dirname,newdirname.c_str());
	 sprintf(s,"mkdir %s",dirname);
	 system(s);
	 cout << "params " << PXYKMPLTS << " " <<auxkmPXY << " " <<  PltsKMPXY << " "<< PltsfacPXY << " "<< PXYKMANT << " " << AuxinKMANT  << " "<< ANTHDZIPfac << " " << AuxKMHDZIP<< std::endl;
	 
	 single_run(argc);                              
       }
   }
 //store overall sweep results

 return 0;
}


//single run so no intricate directory structure.
 int singlemain(int argc, char **argv)
{
 auxmax = auxmax_min;
 globalCLEprod = globalCLEprod_min;
 single_run(argc);
 return 0;
}

int sweepmain(int argc, char **argv)
{
	
  char s[9000];
  sweepcounter=0;
  int i,j;

  for(i=0;i<11;i++)
    for(j=0;j<6;j++)
      {
	sweepHDZIP3[i][j]=0;
	sweepPLTANT[i][j]=0;
	sweepPXY[i][j]=0;
	sweepCLEPXY[i][j]=0;
	sweepPLT[i][j]=0;
	sweepANT[i][j]=0;
      }

  std::string baseDirname= std::string(dirname)+"/";
  for(PXYKMPLTS = PXYKMPLTSmin;PXYKMPLTS<=PXYKMPLTSmax;PXYKMPLTS+=PXYKMPLTSstep)//1
    {
      char PXKPL[20];
      sprintf(PXKPL,"%.1f",PXYKMPLTS);
      std::string PXYKMPLTSname = std::string(baseDirname)+std::string("PXKPL")+ std::string(PXKPL)+std::string("/");
      strcpy(dirname,PXYKMPLTSname.c_str());
      sprintf(s,"mkdir %s",dirname);
      system(s);
      std::string base1Dirname = dirname;
    
      for(auxkmPXY = auxkmPXYmin;auxkmPXY<=auxkmPXYmax;auxkmPXY+=auxkmPXYstep)//2
	{
	  char AUKPX[20];
	  sprintf(AUKPX,"%.1f",auxkmPXY);
	  std::string PXYKMPLTSname =  std::string(base1Dirname)+std::string("AUKPX")+ std::string(AUKPX)+std::string("/");
	  strcpy(dirname,PXYKMPLTSname.c_str());
	  sprintf(s,"mkdir %s",dirname);
	  system(s);
	  std::string base2Dirname = dirname;
	  
	  for(PltsKMPXY = PltsKMPXYmin;PltsKMPXY<=PltsKMPXYmax;PltsKMPXY+= PltsKMPXYstep)//3
	    {
	      char PLKPX[20];
	      sprintf(PLKPX,"%.1f",PltsKMPXY);
	      std::string PltsKMPXYname = std::string(base2Dirname)+std::string("PLKPX")+ std::string(PLKPX)+std::string("/");
	      strcpy(dirname,PltsKMPXYname.c_str());
	      sprintf(s,"mkdir %s",dirname);
	      system(s);
	      std::string base3Dirname = dirname;

	      for(PltsfacPXY = PltsfacPXYmin;PltsfacPXY<=PltsfacPXYmax;PltsfacPXY+=PltsfacPXYstep)//4
		{
		  char PLFPX[20];
		  sprintf(PLFPX,"%.2f",PltsfacPXY);
		  std::string PltsfacPXYname = std::string(base3Dirname)+std::string("PLFPX")+ std::string(PLFPX)+std::string("/");
		  strcpy(dirname,PltsfacPXYname.c_str());
		  sprintf(s,"mkdir %s",dirname);
		  system(s);
		  std::string base4Dirname = dirname;
          
		  for(PXYKMANT = PXYKMANTmin;PXYKMANT<=PXYKMANTmax+1;PXYKMANT+=PXYKMANTstep)//5
		    {
		      char PXKAN[20];
		      sprintf(PXKAN,"%.f",PXYKMANT);
		      std::string PXYKMANTname = std::string(base4Dirname)+std::string("PXKAN")+ std::string(PXKAN)+std::string("/");
		      strcpy(dirname,PXYKMANTname.c_str());
		      sprintf(s,"mkdir %s",dirname);
		      system(s);
		      std::string base5Dirname = dirname;
	        
		      for(AuxinKMANT = AuxinKMANTmin;AuxinKMANT<=AuxinKMANTmax+1;AuxinKMANT+=AuxinKMANTstep)//6
			{
			  char AuKAN[20];
			  sprintf(AuKAN,"%.1f",AuxinKMANT);
			  std::string AuxinKMANTname = std::string(base5Dirname)+std::string("AuKAN")+ std::string(AuKAN)+std::string("/");
			  strcpy(dirname,AuxinKMANTname.c_str());
			  sprintf(s,"mkdir %s",dirname);
			  system(s);
			  std::string base6Dirname = dirname;
              
			  for(ANTHDZIPfac = ANTHDZIPfacmin;ANTHDZIPfac<=ANTHDZIPfacmax+0.01;ANTHDZIPfac+=ANTHDZIPfacstep)//7
			    {
			      char ANFHD[20];
			      sprintf(ANFHD,"%.2f",ANTHDZIPfac);
			      std::string ANTHDZIPfacname = std::string(base6Dirname)+std::string("ANFHD")+ std::string(ANFHD)+std::string("/");
			      strcpy(dirname,ANTHDZIPfacname.c_str());
			      sprintf(s,"mkdir %s",dirname);
			      system(s);
			      std::string base7Dirname = dirname;

			      for(HDZIPKMANT = HDZIPKMANTmin;HDZIPKMANT<=HDZIPKMANTmax+1;HDZIPKMANT+=HDZIPKMANTstep)//8
				{
				  char HDKAN[20];
				  sprintf(HDKAN,"%.1f",HDZIPKMANT);
				  std::string HDZIPKMANTame = std::string(base7Dirname)+std::string("HDKAN")+ std::string(HDKAN)+std::string("/");
				  strcpy(dirname,HDZIPKMANTame.c_str());
				  sprintf(s,"mkdir %s",dirname);
				  system(s);
				  std::string base8Dirname = dirname;             
                
				  for(AuxKMHDZIP = AuxKMHDZIPmin;AuxKMHDZIP<=AuxKMHDZIPmax+1;AuxKMHDZIP+=AuxKMHDZIPstep)//9
				    {
				      char AuKHD[20];
				      sprintf(AuKHD,"%.1f",AuxKMHDZIP);
				      std::string AuxKMHDZIPcname = std::string(base8Dirname)+std::string("AuKHD")+ std::string(AuKHD);
				      strcpy(dirname,AuxKMHDZIPcname.c_str());
				      sprintf(s,"mkdir %s",dirname);
				      system(s);
				      std::string base9Dirname = dirname;
				      cout << base9Dirname << std::endl;


				      for(ANTAuxfac = ANTfacmin; ANTAuxfac<=ANTfacmax+0.1; ANTAuxfac+=ANTfacstep)//10
					{

					  ANTPXYfac=1.-ANTAuxfac;//complementary values adding up to 1

				     
					  char ANTfacAux[20];
					  sprintf(ANTfacAux,"%.1f",ANTAuxfac);
					  std::string ANTfacAuxcname = std::string(base9Dirname)+std::string("ANTfacAux")+ std::string(ANTfacAux);
					  strcpy(dirname,ANTfacAuxcname.c_str());
					  sprintf(s,"mkdir %s",dirname);
					  system(s);
					  std::string base10Dirname = dirname;
					  cout << base10Dirname << std::endl;



				      for(auxmax = auxmax_min;auxmax<auxmax_maxsize;auxmax+=auxmax_stepsize){
					for(globalCLEprod = globalCLEprod_min;globalCLEprod < globalCLEprod_maxsize; globalCLEprod+=globalCLEprod_stepsize)
					  {

					    single_run(argc);
					    
					    
					    //we need to store the outcome (cell type) in a auxin X TDIF matrix
					    //dimension 1: auxin value (0-100, stepsize 10  so 11 entries)
					    //dimension 2: TDIF value (0-100, stepsize 20 so 6 entries)
					    //dimension 3: 3 entries 0: xylem, 1: cambium 3: phloem
					    //first compute dimension 1
					    //note that i=0 is high and i=10 is low auxin
					    i=10 - (int) (auxmax-auxmax_min)/auxmax_stepsize;
					    //second compute dimension 2
					    j=(int)((globalCLEprod-globalCLEprod_min)/globalCLEprod_stepsize);
					    
					    
					    //thirdly determine celltype
					    int xylem= 0;
					    int cambium= 0;
					    int phloem= 0;
					    
					    
					    if((Plts[0]+ANT[0])>75)//87.5) 
					      cambium=1;
					    else if(HDZIP3[0]>30)
					      xylem=1;
					    else
					      phloem=1;
					    
					    
					    
					    //need to create this table and initialize all at 0
					    //make it of type double so we can convert counters 
					    //afterwards to fraction/percentage?
					    //need to make counter for total number of parameter sets
					    //needs to be long int
					    
					    sweepcounter++;
					    sweepresults[i][j][0]+=cambium;
					    sweepresults[i][j][1]+=phloem; 
					    sweepresults[i][j][2]+=xylem; 

					    
					    sweepHDZIP3[i][j]+=HDZIP3[0];
					    sweepPLTANT[i][j]+=Plts[0]+ANT[0];
					    sweepPXY[i][j]+=PXY[0];
					    sweepCLEPXY[i][j]+=PXY[0]+PXYbound[0];
					    sweepPLT[i][j]+=Plts[0];
					    sweepANT[i][j]+=ANT[0];
					  }
				      }
				      }
				    }
				}
			    }
			}
		    }
		}
	    }
	}
    }
  printf("finished sweep, going to compute results\n"); 
  
  printf("sweepcounter is %i\n",sweepcounter);
  sweepcounter/=66;//computing parameter sweeps, not auxin*TDIF matrix
  printf("sweepcounter is %i\n",sweepcounter);
  //computing fraction of parameter sweeps giving certain outcome
  for(i=0;i<11;i++)
    for(j=0;j<6;j++)
      {
	sweepresults[i][j][0]/=sweepcounter;//cambium// R
	sweepresults[i][j][1]/=sweepcounter;//phloem // G
	sweepresults[i][j][2]/=sweepcounter;//xylem  // B

	sweepHDZIP3[i][j]/=sweepcounter;
	sweepPLTANT[i][j]/=sweepcounter;
	sweepPXY[i][j]/=sweepcounter;
	sweepCLEPXY[i][j]/=sweepcounter;
	sweepPLT[i][j]/=sweepcounter;
	sweepANT[i][j]/=sweepcounter;

	//	printf("auxin step %i TDIF step %i results %f %f %f\n",i,j,sweepresults[i][j][0],sweepresults[i][j][1],sweepresults[i][j][2]);
      }
  printf("computed results, going to write them to figure\n");

  MakePNGFileSWEEP(maindirname,sweepresults);  

  MakePNGFileGenes(maindirname,sweepHDZIP3,1);//HDZIP3
  MakePNGFileGenes(maindirname,sweepPLTANT,2);//Plts+ANT
  MakePNGFileGenes(maindirname,sweepPXY,3);//PXY all
  MakePNGFileGenes(maindirname,sweepCLEPXY,4);//PXYbound
  MakePNGFileGenes(maindirname,sweepPLT,5);//Plts
  MakePNGFileGenes(maindirname,sweepANT,6);//ANT


   
 cout << "Finished full set " << std::endl;
 return 0;
}




int main(int argc, char **argv)
{

  Start(argc,argv);
  MakeArrays();

#ifdef PARAMSWEEP
  sweepmain(argc,argv);//vary 9 parameters AND auxin and TDIF
#else
#ifdef MULTIRUN
  multimain(argc,argv);//vary auxin and TDIF
#else
  singlemain(argc,argv);//single value auxin and TDIF
#endif
#endif
 FreeArrays();
 return 0;
}
